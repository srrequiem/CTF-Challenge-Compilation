from ecdsa.ecdsa import Public_key, Private_key, generator_256
from random import randrange
from hashlib import sha1
from Crypto.Util.number import bytes_to_long, long_to_bytes
from Crypto.Util.Padding import pad
from Crypto.Cipher import AES
from secret import flag, nonce
from os import urandom

generator = generator_256
order = generator.order()

d = randrange(1, order)
pubkey = Public_key(generator, generator * d)
privkey = Private_key(pubkey, d)

def sign(msg, nonce):
    hsh = bytes_to_long(sha1(msg.encode()).digest())
    sig = privkey.sign(hsh, nonce)
    return (hsh, int(sig.r), int(sig.s))

def encrypt_flag(flag):
    key = sha1(long_to_bytes(d ^ nonce)).digest()[:16]
    iv = urandom(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    ciphertext = cipher.encrypt(pad(flag, 16))
    return ciphertext.hex(), iv.hex()


print(sign("Would you rather go backwards in time?", nonce * 1955))
print(sign("Or perhaps forwards?", nonce * 2015))

print(encrypt_flag(flag))