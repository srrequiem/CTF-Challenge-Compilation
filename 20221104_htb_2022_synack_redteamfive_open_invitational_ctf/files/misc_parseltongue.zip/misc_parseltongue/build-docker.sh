#!/bin/sh

docker build . -t misc-parseltongue && \
docker run --rm --name=misc-parseltongue -p1337:1337 misc-parseltongue
