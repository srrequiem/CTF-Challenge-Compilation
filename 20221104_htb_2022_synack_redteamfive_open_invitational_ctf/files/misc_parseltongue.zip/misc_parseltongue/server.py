#!/usr/bin/env python3
import string
blacklist = string.ascii_letters + '"\''

payload = input("𝒲𝒽𝒶𝓉 𝓌𝑜𝓊𝓁𝒹 𝓎𝑜𝓊 𝓁𝒾𝓀𝑒 𝓂𝑒 𝓉𝑜 𝒹𝑜? ")
if any(filter(lambda c: c in blacklist, payload)):
    print("𝐼 𝒹𝑜𝓃'𝓉 𝓊𝓃𝒹𝑒𝓇𝓈𝓉𝒶𝓃𝒹 𝓌𝒽𝒶𝓉 𝓎𝑜𝓊 𝓂𝑒𝒶𝓃")
else:
    eval(payload)
