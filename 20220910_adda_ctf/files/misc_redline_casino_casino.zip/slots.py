#!/usr/bin/env python3

from os import urandom
import random

class Slots:

    def __init__(self):
        self.wins = 0

    # guess = minimum number of tries to get 3 of the same number
    def play(self, guess, rand):

        games = []

        for game in range(guess - 1):
            slots = [rand.randint(0,10) for _ in range(3)]
            games.append(slots)
            if slots[0] == slots[1] == slots[2]:
                self.wins = 0
                return (games, False, rand)
                
        slots = [rand.randint(0,10) for _ in range(3)]
        games.append(slots)

        if slots[0] == slots[1] == slots[2]:
            self.wins += 1
            return (games, True, rand)
        else:
            self.wins = 0
            return (games, False, rand)
