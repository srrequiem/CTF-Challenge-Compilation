#!/usr/bin/env python3

from os import urandom
import random

class BlackJack:

    def __init__(self):
        self.wins = 0

    def play(self, cards, rand):
        if cards > 6:
            self.wins = 0
            return ([], [], False, rand)

        player = []
        house = []

        for _ in range(cards):
            player.append(rand.randint(0,12)+1)
            house.append(rand.randint(0,12)+1)

        if sum(player) > 21:
            self.wins = 0
            win = False
            return (player, house, win, rand)

        if sum(player) > sum(house) < 21:
            self.wins += 1
            win = True
        else:
            self.wins = 0
            win = False

        return (player, house, win, rand)
