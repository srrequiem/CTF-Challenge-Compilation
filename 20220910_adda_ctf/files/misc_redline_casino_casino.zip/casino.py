#!/usr/bin/env python3

from os import urandom
from time import sleep
import random, threading
import socketserver as sock
from FLAG import PART1, PART2, PART3
from aesthetics import *
from blackjack import BlackJack
from roulette import Roulette
from slots import Slots


class Service(sock.BaseRequestHandler):
    allow_reuse_address = True

    def handle(self):
        print("New user connected!")

        rand = random.Random(urandom(64))
        self.send(f"{casinoBanner()}\nShall we play a game?\n\n[1] Blackjack\n[2] Roulette (extended)\n[3] Slots")

        while True:
            sleep(0.01)
            response = self.receive()[0]

            if response == "1":
                blackjack = BlackJack()
                self.send(f"{cardsBanner()}\nInput the number of cards you want the dealer to give you.\nPress 'q' to go back.")
                while True:
                    response = self.receive()
                    if response == "q":
                        self.send(f"{casinoBanner()}\nShall we play a game?\n\n[1] Blackjack\n[2] Roulette\n[3] Slots")
                        break
                    player, house, win, rand = blackjack.play(int(response), rand)
                    self.send(f"Player hand: {player}\nHouse hand: {house}\nSuccess: {win}")
                    if blackjack.wins >= 20:
                        self.send(f"Congratulations, here is your prize: {PART1}")
                        self.send(f"{casinoBanner()}\nShall we play a game?\n\n[1] Blackjack\n[2] Roulette\n[3] Slots")
                        break 

            elif response == "2":
                roulette = Roulette()
                self.send(f"{diceBanner()}\nChoose the winning roulette number.\nPress 'q' to go back.")
                while True:
                    response = self.receive()
                    if response == "q":
                        self.send(f"{casinoBanner()}\nShall we play a game?\n\n[1] Blackjack\n[2] Roulette\n[3] Slots")
                        break
                    number, win, rand = roulette.play(int(response), rand)
                    if win:
                        self.send(f"Winning number was: {number}\nYou won!")
                        if roulette.wins >= 20:
                            self.send(f"Congratulations, here is your prize: {PART2}")
                            self.send(f"{casinoBanner()}\nShall we play a game?\n\n[1] Blackjack\n[2] Roulette\n[3] Slots")
                            break
                    else:
                        self.send(f"Winning number was: {number}\nYou lost!")

            elif response == "3":
                slots = Slots()
                self.send(f"{slotBanner()}\nInput the minimum number of tries to get 3 of the same number.\nPress 'q' to go back.")
                while True:
                    response = self.receive()
                    if response == "q":
                        self.send(f"{casinoBanner()}\nShall we play a game?\n\n[1] Blackjack\n[2] Roulette\n[3] Slots")
                        break
                    games, win, rand = slots.play(int(response), rand)
                    for game in games:
                        self.send(str(game))
                    if win:
                        self.send("You won!")
                        if slots.wins >= 20:
                            self.send(f"Congratulations, here is your prize: {PART3}")
                            self.send(f"{casinoBanner()}\nShall we play a game?\n\n[1] Blackjack\n[2] Roulette\n[3] Slots")
                            break
                    else:
                        self.send("You lost!")

            else:
                self.send("Unexpected input!")

    def send(self, string, newline=True):
        if newline: string = string + "\n"
        self.request.sendall(string.encode())

    def receive(self, prompt="> "):
        self.send(prompt, newline=False)
        return self.request.recv(4096).strip().decode("ASCII")


class ThreadService(sock.ThreadingMixIn, sock.TCPServer, sock.DatagramRequestHandler):
    pass


def main():
    host = '0.0.0.0'
    port = 13791

    s = Service
    server = ThreadService((host, port), s)

    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()

    print(f"Server started on port: {port}")
    while True: sleep(1)


if __name__ == '__main__':
    main()
