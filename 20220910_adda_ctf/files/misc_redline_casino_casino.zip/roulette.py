#!/usr/bin/env python3

from os import urandom
import random

class Roulette:

    def __init__(self):
        self.wins = 0

    def play(self, guess, rand):
        winning = rand.randrange(0,4294967295)
        if guess == winning:
            self.wins += 1
            return (winning, True, rand)
        self.wins = 0
        return (winning, False, rand)
