#!/bin/bash
docker rm -f web_paid_forums
docker build -t web_paid_forums .
docker run --name=web_paid_forums --rm -p1337:1337 -it web_paid_forums
