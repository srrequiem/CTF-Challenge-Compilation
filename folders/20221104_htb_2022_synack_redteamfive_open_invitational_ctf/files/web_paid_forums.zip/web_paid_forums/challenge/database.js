const sqlite = require('sqlite-async');

class Database {
	constructor(db_file) {
		this.db_file = db_file;
		this.db = undefined;
	}

	async connect() {
		this.db = await sqlite.open(this.db_file);
	}

	async migrate() {
		return this.db.exec(`
			DROP TABLE IF EXISTS posts;
			CREATE TABLE posts (
				id            INTEGER      NOT NULL PRIMARY KEY AUTOINCREMENT,
				title         VARCHAR(255) NOT NULL,
				description   TEXT         NOT NULL,
				author        VARCHAR(255) NOT NULL,
				created       VARCHAR(255) DEFAULT CURRENT_TIMESTAMP
			);

			INSERT INTO posts (id, title, description, author) VALUES
			    (1, 'Welcome to Paid Forums!', 'I am super delighted to launch this new marketplace for hackers!', 'Tommy Tom'),
			    (2, 'Free Remote Access Trojans and Ransomware Crypters!', 'As promised, here is a list of 20 different RAT and ransomware tools free giveaway: <br>https://0bin.net/paste/wZe46874213q6#tcJePJAP5Maiu4Z4cLfbWOVdUivgZ8dXtn-JeEOopmX', 'Tommy Tom'),
				(3, '2 mill credentials dump', 'Leaked database of the federal bonk investigations that includes username, password, phone, and address. <br>https://0bin.net/paste/wZe46874213q6#tcJePJAP5Maiu4Z4cLfbWOVdUivgZ8dXtn-JeEOopmX', 'EnemyOfBonk');

			DROP TABLE IF EXISTS comments;
			CREATE TABLE comments (
				id            INTEGER      NOT NULL PRIMARY KEY AUTOINCREMENT,
				post_id         INTEGER NOT NULL,
				comment   TEXT         NOT NULL,
				user        VARCHAR(255) NOT NULL,
				created       VARCHAR(255) DEFAULT CURRENT_TIMESTAMP
			);
			INSERT INTO comments (id, post_id, comment, user) VALUES
				(1, 1, 'Super excited about this! Can you share the cheezy ransomware kit v3 please?', 'Rafe Unger'),
				(2, 1, 'Keep an eye out on the forum, it will be posted soon! ;)', 'Tommy Tom'),
				(3, 1, 'Thanks for putting this up!', 'Flask Machine'),
				(4, 2, 'The collection looks promising, thanks for sharing!', 'Leslie Spike'),
				(5, 2, 'Bump!', 'Chester Whitey'),
				(6, 3, 'Thanks for sharing!', 'Jerrio Jerry'),
				(7, 3, 'Whoop, thats a lot of credentials!', 'Tommy Tom');
		`);
	}
	async listPosts() {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT * FROM posts order by id desc');
				resolve(await stmt.all());
			} catch(e) {
				reject(e);
			}
		});
	}
	async getPost(id) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT * FROM posts WHERE id = ?');
				resolve(await stmt.get(id));
			} catch(e) {
				reject(e);
			}
		});
	}
	async getComments(id) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT * FROM comments WHERE post_id = ?');
				resolve(await stmt.all(id));
			} catch(e) {
				reject(e);
			}
		});
	}
}

module.exports = Database;