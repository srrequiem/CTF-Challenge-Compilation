const express        = require('express');
const router         = express.Router({caseSensitive: true});
const bot            = require('../bot');

let db;
let botVisiting = false;

const response = data => ({ message: data });

router.get('/', (req, res) => {
	db.listPosts()
	.then(posts => {
		return res.render('index.html', {posts});
	})
	.catch(e => {
		res.render('index.html');
	})

});

router.get('/posts/:id', (req, res) => {
	const { id } = req.params;
	if(!isNaN(parseInt(id))) {
		db.getPost(parseInt(id))
			.then(post => {
				db.getComments(parseInt(id))
					.then(comments => {
						return res.render('post.html', {post: post , comments: comments});
					})
			})
	} else {
		return res.render('post.html', {error: 'Invalid post ID supplied!'});
	}
});

router.get('/report', (req, res) => {
	res.render('report.html');
});

router.post('/api/report', async (req, res) => {
	const { id } = req.body;
	if (botVisiting) return res.status(403).send(response('Please wait for the previous report to process first!'));
	if(id) {
		botVisiting = true;
		return bot.visitPost(id)
			.then(() => {
				botVisiting = false;
				return res.send(response('Report received successfully!'));
			})
			.catch(e => {
				console.log(e);
				botVisiting = false;
				return res.status(403).send(response('Something went wrong, please try again!'));
			})
	}
	return res.status(500).send(response('Missing required parameters!'));
});

module.exports = database => {
	db = database;
	return router;
};