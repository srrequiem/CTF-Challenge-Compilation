const $ = document.querySelector.bind(document);

window.onload = () => {
	if($('#site-url')) {
		$('#site-url').innerText = window.location.origin + '/posts/ ';
		$('#reportBtn').addEventListener('click', report);
	}
	let params = parseParams(location.href);
	if (params.hasOwnProperty('search')) {
		$('#search-res').style.display = 'block';
		$('#search-msg').innerHTML = `Search results for "${params.search}" :`;
		// todo: add search feature
	}
}

const report = async () => {
	card = $('#resp-msg');
	$('#reportBtn').disabled = true;
	card.style.display = 'block';
	card.innerText = 'Submitting your report...';
	id = $('#report-id').value;
	await fetch('/api/report', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
		},
		body: JSON.stringify({id}),
	})
	.then(resp => resp.json()
	.then(response => {
		$('#reportBtn').disabled = false;
		if (resp.status == 200) {
			card.innerText = 'Your report is submitted and reviewed!';
		}
		else {
			if (response.hasOwnProperty('message')) {
				card.innerText = response.message;
				return;
			}
			card.innerText = 'Something went wrong, please try again!';
		}
	}))
	.catch((error) => {
		console.log(error);
		card.innerText = 'Something went wrong, please try again!';
		$('#reportBtn').disabled = false;
	});
}