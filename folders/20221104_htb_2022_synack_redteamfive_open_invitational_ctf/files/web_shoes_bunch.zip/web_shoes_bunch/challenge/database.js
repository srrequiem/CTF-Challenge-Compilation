const { Pool } = require('pg')

class Database {

    constructor() {
        this.connection = new Pool({
            host: '127.0.0.1',
            user: 'postgres',
            database: 'shoes_bunch',
            port: 5432,
        });
    }

    async listShoes() {
        return new Promise(async (resolve, reject) => {
            let stmt = 'SELECT * FROM shoes';

            this.connection.query(stmt, (err, result) => {
                if (err)
                    reject(err);
                if (!result) return resolve([]);
                if (result.length) resolve(result[0].rows);
                resolve(result.rows);
            })
        });
    }

    async getShoe(id) {
        return new Promise(async (resolve, reject) => {
            let stmt = 'SELECT * FROM shoes WHERE id=$1';
            this.connection.query(stmt, [id], (err, result) => {
                if(err)
                    reject(err)
                if (!result) return resolve([]);
                if (result.length) resolve(result[0].rows);
                resolve(result.rows);
            })
        });
    }

    async searchShoes(query, filter) {
        return new Promise(async (resolve, reject) => {
            let stmt = `SELECT * FROM shoes WHERE name ILIKE '%${query}%'`;
            if (typeof(filter) !== "undefined") {
                stmt += `AND type = '${filter}'`;
            }
            try {
                await this.connection.query(stmt, (err, result) => {
                    if (err) reject(err);
                    if (!result) return resolve([]);
                    if (result.length) resolve(result[0].rows);
                    resolve(result.rows);
                })
            }
            catch(e) {
                resolve([]);
            }
        });
    }

}

module.exports = Database;