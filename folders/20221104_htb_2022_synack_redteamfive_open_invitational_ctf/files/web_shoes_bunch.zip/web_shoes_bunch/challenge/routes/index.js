const express        = require('express');
const router         = express.Router();

router.get('/', async (req, res) => {
	return db.listShoes()
		.then(shoesList => {
			res.render('index.html', {shoesList: shoesList});
		})
		.catch(() => res.render("index.html", {error: true}))
});

router.get('/shop', async (req, res) => {
	return db.listShoes()
		.then(shoesList => {
			res.render('shop.html', {shoesList: shoesList});
		})
		.catch(() => res.render("shop.html", {error: true}))
});

router.get('/shop/search', async (req, res) => {
	const {query, filter} = req.query;

	if (typeof(query) !== "string" || (typeof(filter) !== "undefined" && typeof(filter) !== "string"))
		return res.status(500).render("shop.html", {error: "invalid data supplied"});

	return db.searchShoes(query, filter)
		.then(shoesList => {
			res.render('shop.html', {shoesList: shoesList, query, filter});
		})
		.catch(() => res.status(500).render("shop.html", {error: "Your query didn't yield any results!"}))
});


router.get('/shoes/:id', async (req, res) => {
	if(req.params.id){
		return db.getShoe(parseInt(req.params.id))
			.then(rows => {
				res.render("shop-single.html", {shoe: rows[0]})
			})
			.catch(() => res.render("shop-single.html", {error: true}))
	}
	return res.redirect('/');
});

router.get('/logout', (req, res) => {
	res.clearCookie('session');
	return res.redirect('/');
});

module.exports = () => {
	return router;
};