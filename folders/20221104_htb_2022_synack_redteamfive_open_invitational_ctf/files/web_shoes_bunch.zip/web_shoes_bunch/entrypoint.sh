#!/bin/ash

# Secure entrypoint
chmod 600 /entrypoint.sh

# create DB directories
mkdir -p /run/postgresql /var/lib/postgresql/data
chown -R postgres:postgres /run/postgresql /var/lib/postgresql/data
chmod 0700 /var/lib/postgresql/data

# Initialize PostgreSQL DB cluster
su postgres -c "initdb -D /var/lib/postgresql/data"
echo "host all all 0.0.0.0/0 md5" >> /var/lib/postgresql/data/pg_hba.conf
echo "listen_addresses='*'" >> /var/lib/postgresql/data/postgresql.conf

# Start PostgreSQL
su postgres -c 'pg_ctl start -D /var/lib/postgresql/data'

# Wait for postgreSQL to start
while ! psql -Upostgres --quiet -c 'select 1' 2>&1 1>/dev/null; do echo "not up" && sleep .2; done

# Migrate DB
psql -Upostgres << EOF
CREATE DATABASE shoes_bunch;
\c shoes_bunch;

CREATE TABLE shoes (
  id SERIAL PRIMARY KEY,
  type VARCHAR(100) NOT NULL,
  name VARCHAR(100) NOT NULL,
  image VARCHAR(255) NOT NULL,
  price NUMERIC(5,2) NOT NULL
);

INSERT INTO shoes(type, name, image, price)
VALUES
    ('Party', 'Bella Toes', 's1.jpg', 675.00),
    ('Casual', 'Chikku Loafers', 's2.jpg', 475.00),
    ('Casual', '(SRV) Sneakers', 's3.jpg', 575.00),
    ('Casual', 'Shuberry Heels', 's4.jpg', 575.00),
    ('Ethnic', 'Red Bellies', 's5.jpg', 575.00),
    ('Party', 'Catwalk Flats', 's6.jpg', 575.00),
    ('Casual', 'Running Shoes', 's7.jpg', 675.00),
    ('Casual', 'Sukun Casuals', 's8.jpg', 775.00),
    ('Casual', 'Bank Sneakers', 's9.jpg', 875.00),
    ('Wedding', 'Suitable Lace Up', 's10.jpg', 675.00),
    ('Ethnic', 'Black Flats', 's11.jpg', 675.00),
    ('Wedding', 'Elevator Shoes', 's12.jpg', 675.00);
EOF

/usr/bin/supervisord -c /etc/supervisord.conf