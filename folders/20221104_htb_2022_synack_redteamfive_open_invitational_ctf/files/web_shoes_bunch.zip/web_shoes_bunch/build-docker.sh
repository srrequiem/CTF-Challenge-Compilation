#!/bin/bash
docker rm -f web_shoes_bunch
docker build -t web_shoes_bunch . && \
docker run --name=web_shoes_bunch --rm -p1337:1337 -it web_shoes_bunch