const path              = require('path');
const express           = require('express');
const nunjucks          = require('nunjucks');
const { unflatten }     = require('flat');
const router            = express.Router();

router.get('/', (req, res) => {
    return res.sendFile(path.resolve('views/index.html'));
});

router.post('/api/submit', (req, res) => {
	const { artist } = unflatten(req.body);
	let auth = req.session.auth;

	if (artist.name.includes('Haigh') || artist.name.includes('Westaway') || artist.name.includes('Gingell')) {
		return res.json({
			'response': nunjucks.renderString('Hello {{ user }}, thank you for letting us know!', {user: auth.user})
		});
	} else {
		return res.json({
			'response': 'Please provide us with the full name of an existing member.'
		});
	}
});

module.exports = router;