#!/bin/bash
docker build --no-cache --tag=gunship .
docker run -p 1337:1337 --name=gunship --rm gunship
