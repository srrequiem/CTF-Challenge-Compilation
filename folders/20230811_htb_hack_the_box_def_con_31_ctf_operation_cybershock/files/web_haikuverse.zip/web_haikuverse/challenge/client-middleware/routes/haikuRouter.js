const express = require("express");
const router = express.Router();
const axios = require("axios");
const path = require("path");
const { v4: uuidv4 } = require('uuid');

const API_URL = process.env.API_URL || "http://localhost:1338"
const FLAG = process.env.FLAG || "flag{}"

const instance = axios.create({
    baseURL: API_URL
  });

var admins_haikus = {
    "mia":"The perfect haiku. Wow so many syllables. Good 5 7 5.",
    "ken":"Snow on Mount Fuji. Makes for beautiful picture. But it's very cold.",
    "ammy":"I dropped my ice cream. The world's dark cruelty haunts me. I miss my ice cream."
}

router.get("/", function (req, res) {
    if (req.session){
        return res.sendFile(path.resolve('views/poem.html'));
    } else {
        return res.redirect("/haiku/register");
    }
});

/*===== USER ENDPOINTS =====*/
router.get('/register', (req, res) => {
    return res.sendFile(path.resolve('views/register.html'));
});

router.post('/register', (req, res) => {
    let {username, password} = req.body;
    console.log(req.body);
    let apiBody = JSON.parse(`{"uID":"${uuidv4()}", "username":"${username}", "password":"${password}"}`);
    try {
        instance.post('/new-user', apiBody).then( (api_resp) => {
            if (api_resp.status == 200) {
                req.session.uid = apiBody["uID"];
                req.session.username = apiBody["username"];
                console.log(req.session);
                return res.redirect("/haiku");
            } else {
                return res.status(500).send("API error!");
            }
        });
    } catch (e) {
        reject(e);
    }
});

/*===== HAIKU ENDPOINTS =====*/
const template = (poem) => `
<html>
<head>
<link rel='stylesheet' href='/static/css/style.css'>
</head>
<body>
<p>${poem}</p>
</body>
</html>
`;

router.get("/poems", function (req, res) {
    if (!req.session){
        return res.status(403).send("Please sign in");
    }

    let randompoem = Object.keys(admins_haikus)[Math.floor(Math.random() * Object.keys(admins_haikus).length)];
    return res.status(200).send(template(admins_haikus[randompoem]));
    
});

router.post("/poem", function (req, res) {
    if (!req.session){
        return res.status(403).send("Please sign in");
    }
    var url = "/validate-admin/" + req.session.uid;
    instance.get(url).then( (api_resp) => {
        if (api_resp.status !== 200) {
            return res.status(403).send("no admin? no poem");
        }
    });
    const NOPROTO = ['constructor', 'prototype', '__proto__'];
    if (Object.keys(req.body).some(key => NOPROTO.includes(key))){
        return res.status(400).send("NO");
    }
    if (typeof req.body.poem === "object"){
        for (const key in req.body.poem){
            admins_haikus[req.session.username][key] = req.body.poem[key];
        }
    }
    return res.redirect("/");
});

/*==========API UTILITIES==========*/
router.get("/validate-api", function (req, res) {
    const body = {
        flag: FLAG,
        all_admins: admins_haikus
    };
    instance.post('/validate', body, {timeout: 5000}).then( (api_resp) => {
        if (api_resp.status == 200) {
            return res.status(200).send("All systems green");
        } else {
            return res.status(500).send("API error!");
        }
    });
});

module.exports = router;