const express = require("express");
const path = require('path');
const session = require('express-session');
const haiku = require("./routes/haikuRouter.js");
const crypto = require('crypto');

const CLI_PORT = process.env.CLI_PORT || 1337;
const SECRET = crypto.randomBytes(32).toString('hex');
const app = express();

app.set('views', './views');
app.use('/static', express.static(path.resolve('static')));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  name: "session",
  secret: SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
      secure: false,
      httpOnly: true,
      maxAge: 1000 * 60 * 10
  }
}));
app.use("/haiku", haiku);

app.get('/', (req, res) => {
  return res.redirect('user/register');
});

app.all('*', (req, res) => {
  return res.status(404).send({
    message: '404: PAGE NOT FOUND'
    });
  });

app.listen(CLI_PORT, () => console.log(`Client-Middleware server listening on port ${CLI_PORT}`));