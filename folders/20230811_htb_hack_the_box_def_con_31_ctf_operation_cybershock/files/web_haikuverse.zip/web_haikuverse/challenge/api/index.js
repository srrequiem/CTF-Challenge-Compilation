const express = require('express');
const app = express();
const db = require('better-sqlite3')('db.sqlite3')
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const PORT = process.env.API_PORT || 1338;


db.exec(`
    DROP TABLE IF EXISTS users;
    
    CREATE TABLE users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        uID TEXT NOT NULL UNIQUE,
        username TEXT NOT NULL UNIQUE,
        password TEXT,
        admin INTEGER
    );

    INSERT INTO users (uID, username, password, admin) VALUES ('${uuidv4()}' ,'mia', '${ crypto.randomBytes(32).toString('hex') }', 1);
    INSERT INTO users (uID, username, password, admin) VALUES ('${uuidv4()}' ,'ken', '${ crypto.randomBytes(32).toString('hex') }', 1);
    INSERT INTO users (uID, username, password, admin) VALUES ('${uuidv4()}' ,'ammy', '${ crypto.randomBytes(32).toString('hex') }', 1);
`);



app.get('/', (req, res) => {
    console.log("IN ROOT");
    res.status(200).send('Welcome to the poem API');
});

app.post('/new-user', (req, res) => {
    let {username, password, uID} = req.body;
    console.log(req.body);
    console.log(req.body.username);

    try {
        const stmt = db.prepare("INSERT INTO users (username, password, uID, admin) VALUES (?, ?, ?, 1);");
        const user = stmt.run( username, password, uID);
        console.log(user);
        if (user){
            res.status(200).json("{'success':true}");
        } else {
            res.status(500).send('Error attempting to insert a new user!');
        }
    } catch (e) {
        console.log(e);
        res.status(500).send('Error attempting to insert a new user!');
    }
});

app.get('/validate-admin/:uid', async function (req, res) {
    console.log("im in validate-admin");
    let id = req.params.uid;
    console.log(id);

    //SQL check that id is in user table and has admin flag set
    const stmt = db.prepare(`SELECT * FROM users WHERE admin=1 AND uID=?`);
    const admin = stmt.get(id);
    if (admin){
        return res.status(200).json("{'success': true}");
    } else {
        return res.status(404).json("{'success': false}");
    } 
});

app.post('/validate', (req, res) => {
    console.log("asd");
    let {flag, all_admins} = req.body;
    //flag regex check
    let valid;

    //check number of admins
    const statement = db.prepare(`SELECT COUNT(uID) FROM users WHERE admin=1`);
    const numAdmins = statement.get();
    
    let adminNum;
    if (numAdmins['COUNT(uID)'] !== Object.keys(all_admins).length) {
        adminNum = numAdmins['COUNT(uID)']
    }

    return res.status(200).json({
        success: "true",
        admins: adminNum, 
        flag: valid
    });

  })

app.listen(PORT, () => console.log(`API listening on port ${PORT}`));

