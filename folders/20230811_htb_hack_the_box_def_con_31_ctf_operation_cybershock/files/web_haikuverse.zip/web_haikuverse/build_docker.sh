#!/bin/bash
docker rm -f haiku
docker build --tag=haiku .
docker run -p 1337:1337 --rm --name=haiku -it haiku
