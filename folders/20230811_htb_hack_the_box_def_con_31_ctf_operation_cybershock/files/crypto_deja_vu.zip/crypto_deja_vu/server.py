import ecdsa
import random
import hashlib
from secret import FLAG


class ECDSA:

    def __init__(self, curve=ecdsa.SECP256k1):
        self.curve = curve
        self.nonce = random.randrange(1, 2**127)
        self.sk = ecdsa.SigningKey.from_string(FLAG, curve=self.curve)

    def sign(self, message):
        hash = hashlib.sha256(message.encode()).digest()
        return self.sk.sign(hash, k=self.nonce).hex()


def menu():
    print("[F]ingerprint")
    print("[P]passphrase")
    option = input("> ")
    return option


def main():
    print("How would you like to unlock the door?")
    ecdsa = ECDSA()
    while True:
        option = menu()

        if option == 'F':
            message = input('Place you finger in the screen: ')
            signature = ecdsa.sign(message)
            print(f'Signature: {signature}\n')
        elif option == 'P':
            secret = input('Enter the secret passphrase: ')
            if secret == FLAG:
                print('Door Unlocked!\n')
            else:
                print('Wrong passphrase\n')


if __name__ == "__main__":
    main()
