const sqlite = require('sqlite-async');
const crypto = require('crypto');

class Database {
    constructor(db_file) {
        this.db_file = db_file;
        this.db = undefined;
    }

    async connect() {
        this.db = await sqlite.open(this.db_file);
    }

    async migrate() {
        let password = crypto.randomBytes(16).toString('hex');
        console.log(password);
        return this.db.exec(`
            DROP TABLE IF EXISTS users;
            CREATE TABLE IF NOT EXISTS users (
                id            INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                username      VARCHAR(255) NOT NULL UNIQUE,
                asn           VARCHAR(255) NOT NULL,
                password      VARCHAR(255) NOT NULL
            );

            INSERT INTO users(username, asn, password)
            VALUES
            (
                'admin',
                'AS${crypto.randomBytes(3).toString('hex')}-${crypto.randomBytes(4).toString('hex')}',
                '${password}'
            );

            DROP TABLE IF EXISTS surveys;
            CREATE TABLE IF NOT EXISTS surveys (
                id           BLOB PRIMARY KEY DEFAULT (substr(CAST(random() AS TEXT), 3)),
                name         VARCHAR(255) NOT NULL,
                group_label  VARCHAR(255) NOT NULL
            );

            INSERT INTO surveys(id, name, group_label)
            VALUES
            (
                '195374017314936197',
                'Citizen Evaluation Survey',
                'I’m under 18 years old'
            ),
            (
                '345514276616972501',
                'Citizen Evaluation Survey',
                'I’m over 18 years old'
            );

            DROP TABLE IF EXISTS questions;
            CREATE TABLE IF NOT EXISTS questions (
                id           BLOB PRIMARY KEY DEFAULT (substr(CAST(random() AS TEXT), 3)),
                survey_id    TEXT,
                type         VARCHAR(50) NOT NULL,
                label        VARCHAR(255) NOT NULL,
                options      TEXT NULL,
                required     BOOLEAN NOT NULL,
                placeholder  VARCHAR(255),
                FOREIGN KEY (survey_id) REFERENCES surveys(id)
            );

            INSERT INTO questions (survey_id, type, label, options, required, placeholder)
            VALUES
                ('345514276616972501', 'text', 'How familiar are you with the concept of the "Technological Singularity" and its potential consequences?', NULL, 1, 'Enter your response'),
                ('345514276616972501', 'select', 'How concerned are you about the rise of AI and its impact on job automation?', 'Very Concerned,Somewhat Concerned,Neutral,Not Very Concerned,Not Concerned at All', 1, NULL),
                ('345514276616972501', 'radio', 'Which aspect of AI safety and ethics do you believe is most crucial for researchers and developers to address?', 'Avoiding Bias in AI Algorithms,Ensuring Transparency in AI Decision-Making,Implementing Robust Safety Measures,Preventing AI from Autonomous Weaponization,Regulating AI Development', 1, NULL),
                ('345514276616972501', 'checkbox', 'Select the AI applications you find concerning or potentially dangerous', 'Autonomous Vehicles,AI in Military Applications,AI in Surveillance Systems,AI in Deepfake Technology,AI for Social Engineering', 1, NULL),
                ('345514276616972501', 'text', 'Share your thoughts on the ethical implications of using AI in decision-making processes (e.g., for hiring, medical diagnosis).', NULL, 1, 'Enter your response'),
                ('345514276616972501', 'select', 'How often do you use AI-powered devices or applications in your daily life?', 'Very Often,Often,Occasionally,Rarely,Never', 1, NULL),
                ('345514276616972501', 'radio', 'Which futuristic concept, as depicted in the Terminator series, do you think is most likely to become a reality in the future?', 'Time Travel,Fully Autonomous AI Systems,Cybernetic Enhancements for Humans,AI Controlling Critical Infrastructures', 1, NULL),
                ('345514276616972501', 'checkbox', 'Select the potential benefits of advanced AI that excite you the most', 'Medical Advancements and Cures,Enhanced Efficiency in Industries,Improved Personalized Services,Advancements in Scientific Research,Safer Transportation Systems', 1, NULL),
                ('345514276616972501', 'text', 'How do you envision the relationship between humans and AI evolving in the next 20 years?', NULL, 1, 'Enter your response'),
                ('345514276616972501', 'textarea', 'Describe one scenario where AI could be instrumental in preventing a catastrophic event, similar to the Terminator storyline', NULL, 1, 'Enter your response'),
                ('195374017314936197', 'text', 'What do you think the future will be like in a world dominated by advanced AI and robotics?', NULL, 1, NULL),
                ('195374017314936197', 'select', 'How comfortable are you interacting with AI-powered chatbots or virtual assistants?', 'Very Comfortable,Somewhat Comfortable,Neutral,Uncomfortable,Very Uncomfortable', 1, NULL),
                ('195374017314936197', 'radio', 'Which futuristic technology do you find most intriguing?', 'Virtual Reality (VR),Augmented Reality (AR),Self-Driving Cars,Drones,Robotics', 1, NULL),
                ('195374017314936197', 'checkbox', 'Which of the following AI applications do you currently use or are interested in?', 'Social Media Algorithms,Personalized Recommendations,Voice Assistants,AI in Video Games,AI in Healthcare', 1, NULL),
                ('195374017314936197', 'textarea', 'Describe one positive and one negative impact of AI on society or daily life.', NULL, 1, NULL);

            DROP TABLE IF EXISTS survey_answers;
            CREATE TABLE IF NOT EXISTS survey_answers (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                username     VARCHAR(255),
                survey_id    TEXT,
                question_id  TEXT,
                answer       TEXT,
                CONSTRAINT unique_answer UNIQUE (username, survey_id, question_id)
            );

            DROP TABLE IF EXISTS contact_queries;
            CREATE TABLE IF NOT EXISTS contact_queries (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                username     VARCHAR(255),
                asn          VARCHAR(255),
                query        TEXT
            )

        `);
    }

    async registerUser(user, asn, pass) {
        return new Promise(async (resolve, reject) => {
            try {
                let stmt = await this.db.prepare('INSERT INTO users (username, asn, password) VALUES ( ?, ?, ?)');
                resolve((await stmt.run(user, asn, pass)));
            } catch(e) {
                reject(e);
            }
        });
    }

    async loginUser(user, pass) {
        return new Promise(async (resolve, reject) => {
            try {
                let stmt = await this.db.prepare('SELECT username, asn FROM users WHERE username = ? and password = ?');
                resolve(await stmt.get(user, pass));
            } catch(e) {
                reject(e);
            }
        });
    }

    async getUser(user) {
        return new Promise(async (resolve, reject) => {
            try {
                let stmt = await this.db.prepare('SELECT * FROM users WHERE username = ?');
                resolve(await stmt.get(user));
            } catch(e) {
                reject(e);
            }
        });
    }

    async getUserByAsn(asn) {
        return new Promise(async (resolve, reject) => {
            try {
                let stmt = await this.db.prepare('SELECT * FROM users WHERE asn = ?');
                resolve(await stmt.get(asn));
            } catch(e) {
                reject(e);
            }
        });
    }

    async checkUser(user) {
        return new Promise(async (resolve, reject) => {
            try {
                let stmt = await this.db.prepare('SELECT username FROM users WHERE username = ?');
                let row = await stmt.get(user);
                resolve(row !== undefined);
            } catch(e) {
                reject(e);
            }
        });
    }


    async getSurveys() {
        return new Promise(async (resolve, reject) => {
            try {
                let stmt = await this.db.prepare('SELECT * FROM surveys');
                resolve(await stmt.all());
            } catch(e) {
                reject(e);
            }
        });
    }

    async getQuestions(id) {
        return new Promise(async (resolve, reject) => {
            try {
                let stmt = await this.db.prepare('SELECT * FROM questions WHERE survey_id = ?');
                resolve(await stmt.all(id));
            } catch(e) {
                reject(e);
            }
        });
    }

    async storeAnswers(username, surveyId, answers) {
        return new Promise(async (resolve, reject) => {
            try {
                const sql = `
                INSERT OR REPLACE INTO survey_answers (username, survey_id, question_id, answer)
                VALUES ${Object.entries(answers).map(([questionId, answer]) => '(?, ?, ?, ?)').join(',')}`;

                let stmt = await this.db.prepare(sql);
                Object.entries(answers).forEach(([questionId, answer]) => {
                    stmt.run(username, surveyId, questionId, answer);
                });

                resolve(await stmt.finalize());
            }
            catch(e) {
                reject(e);
            }
        })
    }

    async getAnswers(username, survey_id) {
        return new Promise(async (resolve, reject) => {
            try {
                let stmt = await this.db.prepare('SELECT question_id, answer FROM survey_answers WHERE username = ? and survey_id = ?');
                resolve(await stmt.all(username, survey_id));
            } catch(e) {
                reject(e);
            }
        });
    }

    async getUserSurveys(username) {
        return new Promise(async (resolve, reject) => {
            try {
                let stmt = await this.db.prepare(`
                    SELECT DISTINCT survey_id, surveys.name, username FROM survey_answers
                    LEFT JOIN surveys ON surveys.id = survey_answers.survey_id
                    WHERE username = ?;
                `);
                resolve(await stmt.all(username));
            } catch(e) {
                reject(e);
            }
        });
    }

    async addQuery(query, username, asn) {
        return new Promise(async (resolve, reject) => {
            try {
                let stmt = await this.db.prepare(`INSERT INTO contact_queries (query, username, asn) VALUES(?, ?, ?)`);
                resolve(await stmt.run(query, username, asn));
            } catch(e) {
                reject(e);
            }
        });
    }

    async getQueries() {
        return new Promise(async (resolve, reject) => {
            try {
                let stmt = await this.db.prepare('SELECT * from contact_queries');
                resolve(await stmt.all());
            } catch(e) {
                reject(e);
            }
        });
    }

    async clearQueries() {
        return new Promise(async (resolve, reject) => {
            try {
                let stmt = await this.db.prepare('DELETE from contact_queries');
                resolve(await stmt.run());
            } catch(e) {
                reject(e);
            }
        });
    }
}

module.exports = Database;