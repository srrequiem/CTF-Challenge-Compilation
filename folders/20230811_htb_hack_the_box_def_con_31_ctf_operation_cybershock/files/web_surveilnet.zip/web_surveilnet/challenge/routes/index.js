const bot             = require('../bot');
const express         = require('express');
const router          = express.Router();
const JWTHelper       = require('../helpers/JWTHelper');
const AuthMiddleware  = require('../middleware/AuthMiddleware');

let db;
let botVisting = false;
const response = data => ({ message: data });

router.get('/', (req, res) => {
    return res.render('login.html');
});

router.post('/api/register', async (req, res) => {
    const { username, asn, password } = req.body;

    if (username && asn && password) {
        return db.checkUser(username)
            .then(user => {
                if (user) return res.status(401).send(response('User already registered'));
                return db.registerUser(username, asn, password)
                    .then(()  => res.send(response('User registered successfully')))
            })
            .catch(() => res.send(response('Something went wrong')));
    }
    return res.status(401).send(response('Please fill out all the required fields'));
});

router.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    if (username && password) {
        return db.loginUser(username, password)
            .then(user => {
                let token = JWTHelper.sign(user);
                res.cookie('session', token, { maxAge: 3600000 });
                return res.send(response('User authenticated successfully'));
            })
            .catch(() => res.status(403).send(response('Invalid username or password')));
    }
    return res.status(500).send(response('Missing parameters!'));
});

router.get('/next', AuthMiddleware, async (req, res) => {

    return res.render('next.html', { user: req.user });
});

router.get('/survey', AuthMiddleware, async (req, res) => {

    return res.render('survey.html', { user: req.user });
});

router.get('/api/survey/list', AuthMiddleware, async (req, res, next) => {
    const surveys = await db.getSurveys();

    return res.json(surveys);
});

router.get('/api/survey/:id', AuthMiddleware, async (req, res, next) => {
    const { id } = req.params;
    const questions = await db.getQuestions(id);
    const answers = await db.getAnswers(req.user.username, id);

    return res.json({questions, answers});
});

router.post('/api/survey/:id/submit', AuthMiddleware, async (req, res, next) => {
    const { id } = req.params;
    const answers = req.body;

    if (!answers || typeof answers !== 'object' || Array.isArray(answers)) {
        return res.status(403).send(response('Missing required parameters'));
    }

    for (const key in answers) {
        if (typeof key !== 'string' || typeof answers[key] !== 'string') {
            return res.status(403).send(response('Missing required parameters'));
        }
    }

    return db.storeAnswers(req.user.username, id, answers)
        .then(() => {
            return res.send(response('Survey answers submitted successfully'));
        })
        .catch((e) => {
            console.log(e);
            res.status(500).send(response('Something went wrong'));
        });

});


router.get('/user/:asn', AuthMiddleware, async (req, res) => {
    const { asn } = req.params;

    try {
        const user = await db.getUserByAsn(asn);
        const surveys = await db.getUserSurveys(user.username);

        return res.render('profile.html', { user, surveys });
    }
    catch(e) {
        console.log(e);
        return res.send(response('Something went wrong'));
    }
});

router.get('/contact', AuthMiddleware, async (req, res) => {

    return res.render('contact.html', { user: req.user });
});

router.post('/api/contact', AuthMiddleware, async (req, res) => {

    const { query } = req.body;

    if (botVisting) return res.status(500).send('Rate limited');

    const user = await db.getUser(req.user.username);

    try {
        await db.addQuery(query, user.username, user.asn);

        botVisting = true;
        await bot.reviewQueries();
        botVisting = false;
        return res.send(response('Your query has been submitted'));
    }
    catch(e) {
        console.log(e);
        botVisting = false;
        return res.send(response('Something went wrong'));
    }
});

router.get('/admin/queries', AuthMiddleware, async (req, res) => {

    if (req.user.username != 'admin') return res.redirect('/dashboard');

    const queries = await db.getQueries();

    await db.clearQueries();

    return res.render('admin-queries.html', { user: req.user, queries });
});

router.get('/logout', (req, res) => {
    const { returnTo } = req.query;

    res.clearCookie('session');
    return res.redirect(returnTo ? returnTo : '/');
});

module.exports = database => {
    db = database;
    return router;
};