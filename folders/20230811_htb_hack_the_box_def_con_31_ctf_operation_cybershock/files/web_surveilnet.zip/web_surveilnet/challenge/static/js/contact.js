$(function() {
    $('#submit').on('click', submitForm);
});


const submitForm = async () => {
    let card = $('#response-msg');
    card.text('Please Wait...');
    card.show();

    const query = $('#query').val();

    if (query.trim() == '') {
        card.text('Please fill out the message box first.');
        return;
    }

    await fetch(`/api/contact`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({query}),
    })
        .then(async (response) => {
            let data = await response.json();
            if (data.message) {
                card.text(data.message);
            }
        })
        .catch((error) => {
            console.log(error);
        });
}
