
$(function() {
    loadSurveyIds();
    $("#age-group").on('change', function() {
        location.href = '/survey?id=' + $(this).val();
    });
});

const loadSurveyIds = () => {
    fetch('/api/survey/list')
    .then(res => res.json())
    .then(surveys => {
        for (let survey of surveys) {
            $('#age-group').append(
                `<option value="${ survey.id }">${ survey.group_label }</option>`
            );
        }
    })
    .catch(e => {
        console.log(e);
    });
}