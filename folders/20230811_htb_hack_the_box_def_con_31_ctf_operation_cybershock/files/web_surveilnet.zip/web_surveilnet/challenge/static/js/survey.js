$(function() {
    let params = new URLSearchParams(location.search);
    let id = params.get('id');
    if (id) loadSurvey(id);
    else location.href = '/next';

    let description = $('#description');
    let typewriter = new Typewriter(description[0], {
        loop: false,
        delay: 55,
    });
    typewriter.typeString($('#caption').html().toString()).start();
});


const loadSurvey = async (id) => {
    await fetch(`/api/survey/${id}`)
        .then(async (response) => {
            let data = await response.json();
            if (response.status == 200) {
                if (data.questions) populateForm(data.questions, id);
                if (data.answers) populateAnswers(data.answers);
            }
        })
        .catch((error) => {
            console.log(error);
        });
}

const populateForm = (questions, id) => {
    let form = $('<form></form>').attr('id', 'survey-form');

    for (let i = 0; i < questions.length; i++) {
        let question = questions[i];
        let input, label, p, options;

        switch (question.type) {
            case 'text':
            case 'email':
            case 'number':
                input = $('<input>').attr({
                    'type': question.type,
                    'id': question.id,
                    'name': question.id,
                    'placeholder': question.placeholder,
                    'required': question.required
                });
                break;

            case 'radio':
            case 'checkbox':
                let fieldset = $('<fieldset></fieldset>');
                let legend = $('<legend></legend>').text(question.label);
                fieldset.append(legend);

                options = question.options.split(',');
                for (let j = 0; j < options.length; j++) {
                    let inputId = question.id + '-' + j;

                    input = $('<input>').attr({
                    'type': question.type,
                    'id': inputId,
                    'name': question.id,
                    'value': options[j]
                    });

                    let label = $('<label></label>').attr('for', inputId).text(options[j]);
                    fieldset.append(input, label);
                    fieldset.append($('</br>'));
                }

                input = fieldset;
                break;

            case 'select':
                input = $('<select></select>').attr({
                    'id': question.id,
                    'name': question.id
                });

                options = question.options.split(',');
                for (let k = 0; k < options.length; k++) {
                    let optionElement = $('<option></option>').attr({
                    'id': options[k],
                    'value': options[k]
                    }).text(options[k]);

                    input.append(optionElement);
                }

                break;

            case 'textarea':
                input = $('<textarea></textarea>').attr({
                    'id': question.id,
                    'name': question.id,
                    'placeholder': question.placeholder
                });
                break;
        }

        if (question.type != 'radio' && question.type != 'checkbox') {
            label = $('<label></label>').attr('for', question.id).html(question.label + ' *');
            p = $('<p></p>').append(label, input);
        }
        else {
            p = $('<p></p>').append(input);
        }

        form.append(p);
    }

    let submitButton = $('<input>').attr({
        'type': 'button',
        'id': 'submit',
        'value': 'Submit',
        'class': 'button'
    });

    let submitParagraph = $('<p></p>').append(submitButton);

    form.append(submitParagraph);

    let card = $('<p></p>').attr({
        'class': 'alert alert-information hidden',
        'id': 'response-msg',
    })

    form.append(card);

    $('#form-container').append(form);

    $('#submit').on('click', () => {submitForm(id)});
}

const submitForm = async (id) => {
    let card = $('#response-msg');
    card.text('Please Wait...');
    card.show();

    const formFields = [...new Set($('#survey-form').find(':input').map(function() {
        return $(this).attr('name');
    }).get())];

    const formInputs = $('#survey-form').serializeArray();

    const missingFields = formFields.filter(name => !formInputs.some(obj => obj.name === name));

    if (missingFields.length > 0) {
        card.text('Please fill out all the questions!');
        return;
    }

    let surveyAnswers = {};
    for(let i = 0; i < formInputs.length; i++) {
        fieldName = formInputs[i].name;
        if (surveyAnswers[fieldName]) {
            surveyAnswers[fieldName] = surveyAnswers[fieldName] + ',' + formInputs[i].value;
        }
        else {
            surveyAnswers[fieldName] = formInputs[i].value;
        }
    }

    await fetch(`/api/survey/${id}/submit`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(surveyAnswers),
    })
        .then(async (response) => {
            let data = await response.json();
            if (data.message) {
                card.text(data.message);
            }
        })
        .catch((error) => {
            console.log(error);
        });
}


const populateAnswers = (answers) => {
    for (let i = 0; i < answers.length; i++) {
        let answer = answers[i];
        let input = $('input[name=' + answer.question_id + '], textarea[name=' + answer.question_id + ']');

        if (input.is('input[type="radio"]')) {
            input.filter('[value="' + answer.answer + '"]').prop('checked', true);
        }
        else if (input.is('input[type="checkbox"]')) {
            let options = answer.answer.split(',');
            for(let option of options) {
                input.filter('[value="' + option + '"]').prop('checked', true);
            }
        }
        else if (input.is('select')) {
            input.val(answer.answer);
        }
        else {
            input.val(answer.answer);
        }
    }
}
