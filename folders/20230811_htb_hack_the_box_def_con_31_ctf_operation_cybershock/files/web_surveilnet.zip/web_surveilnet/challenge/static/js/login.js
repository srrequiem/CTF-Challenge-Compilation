$(function() {
    $("#login-btn").on('click', function() {
        auth('login')
    });
    $("#register-btn").on('click', function() {
        auth('register')
    });
});

function toggleInputs(state) {
    $("#username").prop("disabled", state);
    $("#password").prop("disabled", state);
    $("#login-btn").prop("disabled", state);
    $("#register-btn").prop("disabled", state);
}


async function auth(intent) {
    toggleInputs(true); // disable inputs

    // prepare alert
    let card = $(`#${intent}-resp-msg`);
    card.attr("class", "alert alert-information");
    card.hide();

    // validate
    let user = $(`#${intent}-username`).val();
    let pass = $(`#${intent}-password`).val();
    let asn = $(`#register-asn`).val() || '';

    if (user.trim() === '' || pass.trim() === '') {
        toggleInputs(false);
        card.text("Please input username and password first!");
        card.attr("class", "alert alert-danger");
        card.show();
        return;
    }
    if (intent == 'register') {
        if(asn.trim() === '') {
            toggleInputs(false);
            card.text("Please input ASN first!");
            card.attr("class", "alert alert-danger");
            card.show();
            return;
        }
    }

    const data = {
        username: user,
        password: pass,
        asn: asn
    };

    await fetch(`/api/${intent}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        })
        .then((response) => response.json()
            .then((resp) => {
                if (response.status == 200) {
                    card.text(resp.message);
                    card.attr("class", "alert alert-success");
                    card.show();
                    if (intent == 'login'){
                        window.location.href = '/next';
                    }
                    else {
                        setTimeout(() => {$('#reg-log').prop('checked', false).change()}, 700);
                    }
                    return;
                }
                card.text(resp.message);
                card.attr("class", "alert alert-danger");
                card.show();
            }))
        .catch((error) => {
            card.text(error);
            card.attr("class", "alert alert-danger");
            card.show();
        });

    toggleInputs(false); // enable inputs
}