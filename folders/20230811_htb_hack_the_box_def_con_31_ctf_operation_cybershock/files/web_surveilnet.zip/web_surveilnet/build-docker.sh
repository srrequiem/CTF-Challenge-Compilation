#!/bin/bash
docker rm -f web_surveilnet
docker build -t web_surveilnet .
docker run --name=web_surveilnet --rm -p1337:1337 -it web_surveilnet
