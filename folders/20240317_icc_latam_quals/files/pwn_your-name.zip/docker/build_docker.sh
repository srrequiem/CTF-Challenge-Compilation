sudo docker build -t your-name .
sudo docker run -p 1025:1025  -it your-name