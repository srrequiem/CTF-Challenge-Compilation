sudo docker build -t pwn-by-one .
sudo docker run -p 1024:1024  -it pwn-by-one