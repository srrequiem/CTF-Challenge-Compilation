sudo docker build -t something-to-try .
sudo docker run -p 1026:1026  -it something-to-try