sudo docker build -t ret-to-where .
sudo docker run -p 1027:1027  -it ret-to-where 