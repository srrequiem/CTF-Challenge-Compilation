Remote server is using a custom libc, trying to find the right libc is not intended. We suggest you avoid using techniques based on libc for this challenge.
