#!/bin/bash

docker build -t web2pdf .

docker run -it --name=web2pdf -p 80:80 web2pdf
