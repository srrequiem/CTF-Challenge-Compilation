#!/bin/sh

#launch redis
cd /app/db/
redis-server /app/db/redis.conf &

#launch nginx
nginx

#launch crond
crond

#launch uwsgi
cd /app/web/
uwsgi --ini /app/web/uwsgi.ini &

#cleanup files older than 15 minutes, every minute
while sleep 60; do
	find /app/web/pdfs -maxdepth 1 -mmin +15 -type f -exec rm -f {} +
done

exit 0
