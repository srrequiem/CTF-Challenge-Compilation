#!/bin/bash
docker rm -f web_solid_recruit
docker build -t web_solid_recruit .
docker run --name=web_solid_recruit --rm -p1337:1337 -it web_solid_recruit
