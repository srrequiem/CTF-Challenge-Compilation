const sqlite = require('sqlite-async');

class Database {
	constructor(db_file) {
		this.db_file = db_file;
		this.db = undefined;
	}

	async connect() {
		this.db = await sqlite.open(this.db_file);
	}

	async migrate() {
		return this.db.exec(`
            DROP TABLE IF EXISTS users;

            CREATE TABLE IF NOT EXISTS users (
                id         INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                username   VARCHAR(255) NOT NULL UNIQUE,
                password   VARCHAR(255) NOT NULL,
                full_name VARCHAR(255),
                phone   VARCHAR(255),
                birth_date   VARCHAR(255),
                gender   VARCHAR(255),
                address_1   VARCHAR(255),
                address_2   VARCHAR(255),
                city   VARCHAR(255),
                state   VARCHAR(255),
                zip   VARCHAR(255),
                biography   VARCHAR(255)
            );
        `);
	}

	async registerUser(user, pass) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('INSERT INTO users (username, password) VALUES ( ?, ?)');
				resolve((await stmt.run(user, pass)));
			} catch(e) {
				reject(e);
			}
		});
	}

	async loginUser(user, pass) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT username FROM users WHERE username = ? and password = ?');
				resolve(await stmt.get(user, pass));
			} catch(e) {
				reject(e);
			}
		});
	}

	async getUser(user) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT * FROM users WHERE username = ?');
				resolve(await stmt.get(user));
			} catch(e) {
				reject(e);
			}
		});
	}

	async checkUser(user) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT username FROM users WHERE username = ?');
				let row = await stmt.get(user);
				resolve(row !== undefined);
			} catch(e) {
				reject(e);
			}
		});
	}

	async getFormData(username) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT * FROM users WHERE username = ?');
				resolve(await stmt.get(username));
			} catch(e) {
				reject(e);
			}
		});
	}

	async addRecord(jsonData, username) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare(
					`UPDATE users SET full_name = ?, phone = ?, birth_date = ?, gender = ?, address_1 = ?,
					address_2 = ?, city = ?, state = ?, zip = ?, biography = ? WHERE username = ?`);
				resolve(await stmt.run(...Object.values(jsonData), username));
			} catch(e) {
				console.log(e);
				reject(e);
			}
		});
	}

}

module.exports = Database;