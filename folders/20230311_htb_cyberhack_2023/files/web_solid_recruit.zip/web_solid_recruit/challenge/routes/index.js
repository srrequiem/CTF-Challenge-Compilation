const bot            = require('../bot');
const express        = require('express');
const router         = express.Router();
const JWTHelper      = require('../helpers/JWTHelper');
const AuthMiddleware = require('../middleware/AuthMiddleware');

let db;
let botVisting = false;
const response = data => ({ message: data });

router.get('/', (req, res) => {
	return res.render('index.html');
});

router.post('/api/register', async (req, res) => {
	const { username, password } = req.body;

	if (username && password) {
		return db.checkUser(username)
			.then(user => {
				if (user) return res.status(401).send(response('User already registered!'));
				return db.registerUser(username, password)
					.then(()  => res.send(response('User registered successfully!')))
			})
			.catch(() => res.send(response('Something went wrong!')));
	}
	return res.status(401).send(response('Please fill out all the required fields!'));
});

router.post('/api/login', async (req, res) => {
	const { username, password } = req.body;

	if (username && password) {
		return db.loginUser(username, password)
			.then(user => {
				let token = JWTHelper.sign({ username: user.username });
				res.cookie('session', token, { maxAge: 3600000 });
				return res.send(response('User authenticated successfully!'));
			})
			.catch(() => res.status(403).send(response('Invalid username or password!')));
	}
	return res.status(500).send(response('Missing parameters!'));
});


router.get('/dashboard', AuthMiddleware, async (req, res) => {
	return db.getFormData(req.data.username)
		.then(formData => {
			res.render('dashboard.html', { formData });
		})
		.catch(() => res.status(500).send(response('Something went wrong, please try again!')));
});

router.get('/review', async (req, res) => {
	if(req.ip != '127.0.0.1') return res.redirect('/');
	const {username} = req.query;
	return db.getFormData(username)
		.then(formData => {
			res.render('dashboard.html', { formData });
		})
		.catch(() => res.status(500).send(response('Something went wrong, please try again!')));
});


router.post('/api/enroll', AuthMiddleware, async (req, res) => {
	if (botVisting) return res.status(500).send(response('Please wait for previous review to finish first!'));
	let jsonData = req.body;
	if (Object.keys(req.body).length == 10) {
		try{
			await db.addRecord(jsonData, req.data.username);
			botVisting = true;
			await bot.reviewForm(req.data.username);
			botVisting = false;
			return res.send(response('Your information is saved, it will be reviewed shortly!'))
		}
		catch(e) {
			console.log(e);
			botVisting = false;
			return res.send(response('Something went wrong, please try again!'));
		}
	}
	return res.status(403).send(response('Missing parameters!'));
});

router.get('/logout', (req, res) => {
	res.clearCookie('session');
	return res.redirect('/');
});

module.exports = database => {
	db = database;
	return router;
};