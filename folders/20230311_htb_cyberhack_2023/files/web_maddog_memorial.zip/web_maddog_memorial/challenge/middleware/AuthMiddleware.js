const JWTHelper = require('../helpers/JWTHelper');
const crypto    = require('crypto');
const response  = data => ({ message: data });

module.exports = async (req, res, next) => {
	try{
		if (req.cookies.session === undefined) {
			let username = `visitor_${crypto.randomBytes(3).toString('hex')}`;
			let token = await JWTHelper.sign({
				username
			});
			res.cookie('session', token, { maxAge: 259200000 });
			req.data = {
				username: username
			};
			return next();
		}
        return JWTHelper.getKid(req.cookies.session)
			.then(kid => {
				if (kid === undefined) return res.status(500).send(response('Missing kid header claim!'));
                return JWTHelper.verify(req.cookies.session, kid)
                    .then(username => {
                        req.data = username;
                        next();
                    })
                    .catch(() => {
                        res.redirect('/logout');
                    });
            })
            .catch(err => res.status(500).send(response("Something went wrong!")));
	} catch(e) {
		console.log(e);
		return res.status(500).send('Internal server error');
	}
}