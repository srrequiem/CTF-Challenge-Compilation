const express        = require('express');
const router         = express.Router();
const fs             = require('fs');
const AuthMiddleware = require('../middleware/AuthMiddleware');

router.get('/', AuthMiddleware, async (req, res) => {
	return db.getPosts()
		.then(allPosts => {
			flag = null;
			if ( req.data.username === 'admin') flag = fs.readFileSync('./flag', 'utf8');
			res.render('index.html', {allPosts: allPosts, username: req.data.username, flag});
		})
});

router.get('/posts/:id', AuthMiddleware, async (req, res) => {
	if(req.params.id){
		return db.getPost(req.params.id)
			.then(rawData => {
				postData = Object.values(JSON.parse(JSON.stringify(rawData)))
				res.render("post.html", {post: postData[0],  username: req.data.username})
			})
			.catch(() => res.render("post.html", {error: true}))
	}
	return res.redirect('/');
});

router.get('/logout', (req, res) => {
	res.clearCookie('session');
	return res.redirect('/');
});

module.exports = () => { 
	return router;
};