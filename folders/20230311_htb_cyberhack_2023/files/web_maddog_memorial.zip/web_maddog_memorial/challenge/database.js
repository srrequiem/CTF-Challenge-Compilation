let mysql = require('mysql2')

class Database {

    constructor() {
        this.connection = mysql.createConnection({
            host: '127.0.0.1',
            user: 'root',
            password: 'M@k3l@R!d3s$',
            database: 'tannen_memorial'
        });
    }

    async connect() {
        return new Promise((resolve, reject)=> {
            this.connection.connect((err)=> {
                if(err)
                    reject(err)
                resolve()
            });
        })
    }

    async getKeyStore() {
        return new Promise(async (resolve, reject) => {
            let stmt = 'SELECT * FROM keystore';
            this.connection.query(stmt, (err, result) => {
                if(err)
                    reject(err)
                resolve(result)
            })
        });
    }

    async getPosts() {
        return new Promise(async (resolve, reject) => {
            let stmt = 'SELECT * FROM posts';
            this.connection.query(stmt, (err, result) => {
                if(err)
                    reject(err)
                resolve(result)
            })
        });
    }

    async getPost(id) {
        return new Promise(async (resolve, reject) => {
            let stmt = `SELECT * FROM posts WHERE id='${id}'`;
            this.connection.query(stmt, (err, result) => {
                if(err)
                    reject(err)
                resolve(result)
            })
        });
    }

}

module.exports = Database;