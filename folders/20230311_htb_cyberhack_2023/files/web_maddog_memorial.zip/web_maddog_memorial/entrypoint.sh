#!/bin/ash

# Secure entrypoint
chmod 600 /entrypoint.sh

# Initialize & Start MariaDB
mkdir -p /run/mysqld
chown -R mysql:mysql /run/mysqld
mysql_install_db --user=mysql --ldata=/var/lib/mysql
mysqld --user=mysql --console --skip-name-resolve --skip-networking=0 &

# Wait for mysql to start
while ! mysqladmin ping -h'localhost' --silent; do echo "not up" && sleep .2; done

DEVKEY=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 15 | head -n 1)
PRODKEY=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 15 | head -n 1)

mysql -u root << EOF
CREATE DATABASE tannen_memorial;

CREATE TABLE tannen_memorial.keystore (
  kid int(11) NOT NULL AUTO_INCREMENT,
  secret varchar(255) NOT NULL,
  PRIMARY KEY (kid)
);

INSERT INTO tannen_memorial.keystore VALUES (1,'${DEVKEY}');
INSERT INTO tannen_memorial.keystore VALUES (2,'${PRODKEY}');

CREATE TABLE tannen_memorial.posts (
  id int(11) NOT NULL AUTO_INCREMENT,
  title varchar(255) NOT NULL,
  thumbnail varchar(255) NOT NULL,
  content text NOT NULL,
  PRIMARY KEY (id)
);

INSERT INTO tannen_memorial.posts VALUES 
(1,'The Hero','mad1.jpg','Our Ancestor, Buford Tannen, was regarded as a hero for catching the thieves who robbed the Pine City Stage back in 1885. Although he was suspected of robbing the stagecoach earlier, he cleared his name later by identifying the real culprit. He guided the chief marshal to the house of a man named Seamus McFly, where they discovered a payroll from the stagecoach in the house. Hill valley recognized Buford as a hero for his assistance in finding the robbers.'),
(2,'The Cowboy','mad2.jpg','Buford was one of the finest cowboys of the Hill Valley and was often praised for his excellent horse riding skills. He used to take his horse to the old town road, and ride till he could no more.'),
(3,'The Futurist','mad3.jpg','The Tannen family has a neck for being futuristics. Even the modern-day video games about the wild west are often inspired by his persona!'),
(4,'The Gunslinger','mad4.jpg','Buford was known as the fastest gun in the west. He was known for his ability to draw, shoot, and holster a gun in a fraction of a single second. But it was his accuracy that put him in a league above the rest: It was claimed he could draw his weapon, shoot two different targets with precision, and holster his gun in a mere .02 seconds.');

GRANT ALL PRIVILEGES ON tannen_memorial.* TO 'root'@'%' IDENTIFIED BY 'M@k3l@R!d3s$';
FLUSH PRIVILEGES;
EOF

/usr/bin/supervisord -c /etc/supervisord.conf