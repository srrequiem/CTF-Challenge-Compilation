#!/bin/bash
docker rm -f web_maddog_memorial
docker build -t web_maddog_memorial . && \
docker run --name=web_maddog_memorial --rm -p1337:1337 -it web_maddog_memorial