<?php

if(isset($_GET ['url'])){
    $url= $_GET['url'];
    $image = fopen($url, 'rb');
    header("Content-Type: image/png");
    fpassthru($image);
}
?>
<html>
<body>
<!--Flag en /flag.txt-->
<center><h1>Descarga de imagenes</h1></center>
<br><br><br><br><br>
<center>
<form action='.' method='GET'>
Ingresa la url:<input type='text' name='url'>
<br><br>
<input type='submit' name='Descargar'>
</center>
</form>

</body>
</html>