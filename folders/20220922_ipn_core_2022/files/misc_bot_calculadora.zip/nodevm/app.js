const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const router = express.Router();
const vm = require("vm");

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(router);

router.post("/", function (req, res) {
    let vmResponse = {
        type: "",
        res: "",
    };
    try {
        const payloadResponse = vm.runInNewContext(Buffer.from(req.body.payload,'base64').toString('ascii'));
        vmResponse = { ...vmResponse, type: "ok", res: payloadResponse };
    } catch (error) {
        vmResponse = { ...vmResponse, type: "error", res: error.stack };
    } finally {
        res.json(vmResponse);
    }
});

app.listen(3000, function () {
    console.log("Node server running on http://localhost:3000");
});
