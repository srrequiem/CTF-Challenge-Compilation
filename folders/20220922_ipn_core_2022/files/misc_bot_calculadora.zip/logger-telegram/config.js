const dotenv = require("dotenv");
dotenv.config();
module.exports = {
    bot_token: process.env.BOT_TOKEN,
    vm_ip: process.env.VM_IP,
    vm_port: process.env.VM_PORT,
};
