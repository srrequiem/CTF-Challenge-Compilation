const { JsonDB } = require("node-json-db");
const { Config } = require("node-json-db/dist/lib/JsonDBConfig");
const axios = require("axios");
const TelegramBot = require("node-telegram-bot-api");
const { bot_token, vm_ip, vm_port } = require("./config");
const bot = new TelegramBot(bot_token, { polling: true });
const db = new JsonDB(new Config("logs", true, false, "/"));

bot.onText(/\/help/, (msg) => {
    const chatId = msg.chat.id;
    const title = "<strong>Prueba nuestro bot calculadora</strong> \n";
    const desc =
        "Hemos creado un bot para calcular operaciones, y lo hemos metido en un sandbox así estamos protegidos de los hackers 😎.\nEjecuta <code>/calc 1+1</code> para interactuar con nuestra calculadora.";
    const resp = title + desc;

    bot.sendMessage(chatId, resp, {
        parse_mode: "HTML",
    });
});

bot.onText(/\/calc (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const payload = match[1];
    const b64Payload = Buffer.from(payload).toString("base64");
    try {
        db.push(`/${msg.from.id}/${Date.now()}`, {
            type: "info",
            payload,
        });
        axios
            .post(`http://${vm_ip}:${vm_port}`, {
                payload: b64Payload,
            })
            .then((res) => {
                const response = res.data.res;
                const title = "<b>Resultado</b>\n";
                const desc = `<code>${match[1]}=${response}</code>`;
                const resp = title + desc;
                bot.sendMessage(chatId, resp, {
                    parse_mode: "HTML",
                });
            })
            .catch((error) => {
                console.error(error);
            });
    } catch (error) {
        db.push(`/${msg.from.id}/${Date.now()}`, {
            type: "error",
            payload,
            stack: error.stack,
        });
        const title = "Yamete Kudasai\n";
        const desc = "¡Me lastimas 😖!";
        const resp = title + desc;
        bot.sendMessage(chatId, resp);
    }
});
