#!/bin/bash

docker build -t payback .
docker run -p 1337:1337 --name payback --rm -it payback
