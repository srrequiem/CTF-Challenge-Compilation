#pragma once
#define BKD_KDPRINT(_x_) \
                DbgPrint("BKD.SYS: ");\
                DbgPrint _x_;

#define BKD_TYPE 31337

#define IOCTL_BKD_WWW \
    CTL_CODE( BKD_TYPE, 0x900, METHOD_BUFFERED, FILE_ANY_ACCESS  )
#define IOCTL_BKD_RWW \
    CTL_CODE( BKD_TYPE, 0x901, METHOD_BUFFERED, FILE_ANY_ACCESS  )
#define DRIVER_NAME       "BKD"
UNICODE_STRING DEVICE_NAME = RTL_CONSTANT_STRING(L"\\Device\\BKD");
UNICODE_STRING DEVICE_SYMBOLIC_NAME = RTL_CONSTANT_STRING(L"\\??\\BKD");
typedef struct {
    PVOID addr;
    unsigned long long value;
} BkdPl;