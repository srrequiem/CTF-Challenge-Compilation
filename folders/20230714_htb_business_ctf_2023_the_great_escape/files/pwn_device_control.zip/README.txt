For better UX, connect with:

socat `tty`,raw,echo=0 tcp:<IP>:<PORT>

instead of nc <IP> <PORT>
