#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#define MAX_PEOPLE 10
#define MAX_NAME_LEN 30
#define MAX_CON_LEN 15
#define MAX_ADDRESS_LEN 50
#define MAX_BUFFER_SIZE 100

struct Target {
  char target_name[MAX_NAME_LEN];
  char residence_address[MAX_ADDRESS_LEN];
  char contact_number[MAX_CON_LEN];
};

void get_input(char *buffer, size_t buffer_size) {
  int bytes_read = 0;
  bytes_read = read(0,buffer, buffer_size);
  if (buffer[bytes_read-1] == 10)
	  buffer[bytes_read - 1] = '\0';
}

void fill_target(struct Target *p) {
  printf("Enter the target name: ");
  get_input(p->target_name, MAX_NAME_LEN);

  printf("Enter the residence address: ");
  get_input(p->residence_address, MAX_ADDRESS_LEN);

  printf("Enter the contact number: ");
  get_input(p->contact_number, MAX_CON_LEN);
}

void print_target(struct Target *p) {
	printf("Target Name: ");
	write(1,p->target_name,MAX_NAME_LEN);
	printf("Residence Address: ");
	write(1,p->residence_address,MAX_ADDRESS_LEN);
	printf("Contact Number: ");
	write(1,p->contact_number,MAX_CON_LEN);
}

void add_target(struct Target *targets, size_t *num_targets) {
  if (*num_targets >= MAX_PEOPLE) {
    printf("Error: Maximum number of targets reached.\n");
    return;
  }

  struct Target p;
  fill_target(&p);
  targets[*num_targets] = p;
  (*num_targets)++;
}

void search_target(struct Target *targets, size_t num_targets) {
  char name[MAX_NAME_LEN];
  printf("Enter the name of the target you want to lookup: ");
  get_input(name, MAX_NAME_LEN);

  int found = 0;
  for (size_t i = 0; i < num_targets; i++) {
    if (strncmp(targets[i].target_name, name, strlen(name)) == 0) {
      print_target(&targets[i]);
      found = 1;
    }
  }

  if (!found) {
    printf("Target not found.\n");
  }
}

void check_filename(char *file_name){
	if (strstr(file_name, "/") || strstr(file_name, "flag") || strstr(file_name, ".")){
		printf("That doesn't seem like a target identification code to work with\n");
		_exit(0);
	}	
	return;
}

void get_filename(char *file_name){
	printf("Enter the target ID: ");
	scanf("%25s", file_name);
	getchar();
	check_filename(file_name);
}

void save_targets_to_file(struct Target *targets, size_t num_targets, char *file_name) {
  int fp = open(file_name, O_WRONLY | O_CREAT, S_IRWXU | S_IRWXG | S_IRWXO);
  if (fp < 1) {
    printf("Error: Unable to open target identification code.\n");
    return;
  }

  for (size_t i = 0; i < num_targets; i++) {

    write(fp, targets[i].target_name, strlen(targets[i].target_name)>MAX_NAME_LEN?MAX_NAME_LEN:strlen(targets[i].target_name));
    write(fp, targets[i].residence_address, strlen(targets[i].residence_address)>MAX_ADDRESS_LEN?MAX_ADDRESS_LEN:strlen(targets[i].residence_address));
    write(fp, targets[i].contact_number, strlen(targets[i].contact_number)>MAX_CON_LEN?MAX_CON_LEN:strlen(targets[i].contact_number));
  }
  close(fp);
}

void save_target_to_file(struct Target *targets, size_t num_targets, char *file_name) {
	int fp = open(file_name, O_WRONLY | O_CREAT, S_IRWXU | S_IRWXG | S_IRWXO);
	if (fp < 1) {
		printf("Error: Unable to open target identification code.\n");
		return;
	}
	int choice = 0;
	printf("Target selection: ");
	scanf("%d", &choice);
	getchar();
	if(choice < 0 || choice >= num_targets){
		printf("Error: Bad selection\n");
		return;
	}
	write(fp, targets[choice].target_name, MAX_NAME_LEN);
	write(fp, targets[choice].residence_address, MAX_ADDRESS_LEN);
	write(fp, targets[choice].contact_number, MAX_CON_LEN);
	close(fp);
}

void load_targets_from_file(struct Target *targets, size_t *num_targets, char *file_name) {
	int fp = open(file_name, O_RDONLY);
	if (fp < 1) {
		printf("Error: Unable to open target identification code.\n");
		return;
	}

	while (read(fp, targets[*num_targets].target_name, MAX_NAME_LEN) > 0) {
		read(fp,targets[*num_targets].residence_address, MAX_ADDRESS_LEN);
		read(fp,targets[*num_targets].contact_number, MAX_CON_LEN);
		(*num_targets)++;
		if (*num_targets >= MAX_PEOPLE) {
			break;
		}
	}

	close(fp);
}

void remove_targets(struct Target *targets, size_t *num_targets){
	int choice = 0;
	printf("Target to remove: ");
	scanf("%d", &choice);
	
	if (choice > -1 && choice >= *num_targets){
		printf("Selection is out of Range.\n");
		return;
	}

	memmove((void*)&targets[choice], (void*)&targets[choice+1], sizeof(struct Target)**num_targets-choice);
	*num_targets = *num_targets - 1;

}

void main_loop() {
	struct Target targets[MAX_PEOPLE];
	size_t num_targets = 0;
	char file_name[25] = {0};

	char buffer[MAX_BUFFER_SIZE];

	puts("-----------------------------------------------------------");
        puts("              Board of Arodor Tracking Server              ");
        puts("                   [BETA VERSION - v1.0]                   ");
	puts("-----------------------------------------------------------\n");

	printf(
	"=========== Main Menu ===========\n"
	" 1. Initiate Surveillance\n"
	" 2. Target Acquisition\n"
	" 3. Exploit\n"
	" 4. Transmit Data\n"
	" 5. Extract Data\n"
	" 6. Eliminate Targets\n"
	" 7. Terminate Program\n"
	"==================================\n\n> "
	);
	get_input(buffer, MAX_BUFFER_SIZE);

	while (strncmp(buffer, "7",1) != 0) {
		if (strncmp(buffer, "1",1) == 0) {
			get_filename(file_name);
			load_targets_from_file(targets, &num_targets, file_name);
		} else if (strncmp(buffer, "2", 1) == 0) {
			add_target(targets, &num_targets);
		} else if (strncmp(buffer, "3", 1) == 0) {
			search_target(targets, num_targets);
		} else if (strncmp(buffer, "4", 1) == 0) {
			get_filename(file_name);
			save_targets_to_file(targets, num_targets, file_name);
		} else if (strncmp(buffer, "5", 1) == 0) {
			get_filename(file_name);
			save_target_to_file(targets, num_targets, file_name);
		} else if (strncmp(buffer, "6", 1) == 0) {
			remove_targets(targets, &num_targets);
		} else {
			printf("Error: Invalid command.\n");
		}

		puts("");
		printf(
		"=========== Main Menu ===========\n"
		" 1. Initiate Surveillance\n"
		" 2. Target Acquisition\n"
		" 3. Exploit\n"
		" 4. Transmit Data\n"
		" 5. Extract Data\n"
		" 6. Eliminate Targets\n"
		" 7. Terminate Program\n"
		"==================================\n\n> "
		);
		get_input(buffer, MAX_BUFFER_SIZE);

	}
}

void starter(){
	setvbuf(stdin,0,2,0);
	setvbuf(stdout,0,2,0);
	setvbuf(stderr,0,2,0);

	main_loop();
}

int main(int argc, char *argv[]) {
	starter();
	return 0;
}
