#!/bin/bash
docker build --tag=web_redwave .
docker run -p 1337:8080 --rm --name=web_redwave -it web_redwave