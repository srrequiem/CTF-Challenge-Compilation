window.addEventListener('DOMContentLoaded', event => {
    document.getElementById('admin-form').addEventListener('submit', function(e) {
        e.preventDefault();

        let card = document.getElementById("resp-msg");
        card.style.display = 'none';

        let url = document.getElementById("URL").value;
        let body = document.getElementsByTagName("textarea")[0].value;

        fetch('/admin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                url,
                body
            }),
        })
        .then((response) => {
            if (response.status == 200) {
                location.reload();
                return;
            }
            card.innerHTML = 'Something went wrong, please try again!';
            card.style.display = 'block';
        })
        .catch((error) => {
            card.innerHTML = error;
            card.style.display = 'block';
        });
    });
});