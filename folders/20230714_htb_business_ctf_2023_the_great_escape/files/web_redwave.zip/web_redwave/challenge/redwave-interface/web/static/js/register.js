window.addEventListener('DOMContentLoaded', event => {
    document.getElementById('register-form').addEventListener('submit', function(e) {
        e.preventDefault();

        let card = document.getElementById("resp-msg");
        card.style.display = 'none';

        let username = document.getElementById("user").value;
        let password = document.getElementById("pw").value;

        fetch('/register', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
                username,
                password
            }),
		})
		.then((response) => {
            if (response.status == 200) {
                window.location = "/signin";
                return;
            }
            else if (response.status == 400) {
                card.innerHTML = 'Username already exists!';
            }
            else {
                card.innerHTML = 'Something went wrong, please try again!';
            }
            card.style.display = 'block';
        })
		.catch((error) => {
			card.innerHTML = error;
            card.style.display = 'block';
		});
    });
});