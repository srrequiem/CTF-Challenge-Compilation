
window.onload = () => {
    let allBroadcasts;

    fetch('/broadcasts/readall')
}

window.addEventListener('DOMContentLoaded', event => {
    document.getElementById('edit-form').addEventListener('submit', function(e) {
        e.preventDefault();

        let card = document.getElementById("resp-msg");
        card.style.display = 'none';

        let username = document.getElementById("user").innerHTML;
        let uid = document.getElementById("uid").innerHTML;
        let category = document.querySelector('#house').options[document.querySelector('#house').selectedIndex].value;

        fetch('/dashboard', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                UID: uid,
                username,
                category
            }),
        })
        .then((response) => {
            if (response.status == 200) {
                console.log(response.status)
                location.reload();
                return;
            }
            card.innerHTML = 'Something went wrong, please try again!';
            card.style.display = 'block';
        })
        .catch((error) => {
            card.innerHTML = error;
            card.style.display = 'block';
        });
    });
});