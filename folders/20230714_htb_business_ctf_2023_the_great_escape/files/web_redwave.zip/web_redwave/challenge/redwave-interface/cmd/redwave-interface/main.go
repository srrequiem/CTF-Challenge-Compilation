package main

import (
	"gemshop-interface/internal/server"
	"log"
)

func main() {
	s := server.NewServer("http://127.0.0.1:3000")

	log.Fatal(s.Start())
}
