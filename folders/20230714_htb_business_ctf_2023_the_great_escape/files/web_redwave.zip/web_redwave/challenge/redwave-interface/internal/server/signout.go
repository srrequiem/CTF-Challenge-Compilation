package server

import "net/http"

func (s *Server) handleSignOut(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("session_token")
	if err != nil {
		http.Error(w, "You must be logged in to log out :P", http.StatusUnauthorized)
		return
	}

	delete(s.sessions, cookie.Value)
	delCookie := &http.Cookie{
		Name:   "session_token",
		Value:  "",
		Path:   "/",
		MaxAge: -1,
	}
	http.SetCookie(w, delCookie)
	http.Redirect(w, r, "/", http.StatusFound)
}
