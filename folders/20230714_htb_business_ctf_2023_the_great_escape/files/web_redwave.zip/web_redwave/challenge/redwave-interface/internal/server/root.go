package server

import (
	"gemshop-interface/internal/models"
	"net/http"
)

func (s *Server) handleRoot(w http.ResponseWriter, r *http.Request) {
	s.renderTemplate(w, "landing", templateData{
		"user": models.User{
			Username: "Guest",
		},
	})
}
