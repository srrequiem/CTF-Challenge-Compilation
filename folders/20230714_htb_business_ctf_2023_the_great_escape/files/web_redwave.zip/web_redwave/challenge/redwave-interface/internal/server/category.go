package server

import (
	"encoding/json"
	"gemshop-interface/internal/models"
	"io"
	"log"
	"net/http"
)

func (s *Server) handleBroadcast(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("session_token")
	if err != nil {
		http.Error(w, "You must be logged in to access", http.StatusUnauthorized)
		return
	}
	var u = s.sessions[cookie.Value]

	broadcast, err := s.apiClient.ReadUserBroadcast(u)
	if err != nil {
		handleApiError(w, err)
		return
	}

	s.renderTemplate(w, "broadcast", templateData{
		"user":   u,
		"broadcast": broadcast.Description,
	})
}

func (s *Server) handleBroadcastPost(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("session_token")
	if err != nil {
		http.Error(w, "You must be logged in to access", http.StatusUnauthorized)
		return
	}
	var u = s.sessions[cookie.Value]

	postBody, err := io.ReadAll(r.Body)
	if err != nil {
		log.Println(err)
		http.Error(w, "Something went wrong", http.StatusInternalServerError)
		return
	}

	err = s.apiClient.EditUser(postBody, u)
	if err != nil {
		handleApiError(w, err)
		return
	}

	var updatedUser models.User
	json.Unmarshal(postBody, &updatedUser)
	s.sessions[cookie.Value] = updatedUser
	http.Redirect(w, r, "/dashboard", http.StatusFound)
}
