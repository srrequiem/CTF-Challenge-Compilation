package server

import (
	"gemshop-interface/internal/apiclient"
	"gemshop-interface/internal/models"
	"github.com/gorilla/mux"
	"html/template"
	"log"
	"net/http"
	"os"
	"path/filepath"
)

type templateData map[string]any

type Server struct {
	apiClient *apiclient.ApiClient
	sessions  map[string]models.User
}

func NewServer(apiUrl string) *Server {
	return &Server{
		apiClient: &apiclient.ApiClient{
			Url: apiUrl,
		},
		sessions: make(map[string]models.User),
	}
}

func (s *Server) Start() error {
	r := mux.NewRouter()
	path := filepath.Join(getCwd(), "web/static")

	r.PathPrefix("/static/").Handler(http.StripPrefix("/static", http.FileServer(http.Dir(path))))
	r.HandleFunc("/", s.handleRoot)
	r.HandleFunc("/signin", s.handleSignIn).Methods("GET")
	r.HandleFunc("/signin", s.handleSignInPost).Methods("POST")
	r.HandleFunc("/signout", s.handleSignOut)
	r.HandleFunc("/register", s.handleRegister).Methods("POST")
	r.HandleFunc("/dashboard", s.handleBroadcast).Methods("GET")
	r.HandleFunc("/dashboard", s.handleBroadcastPost).Methods("POST")
	r.HandleFunc("/admin", s.handleAdmin).Methods("GET")
	r.HandleFunc("/admin", s.handleAdminPost).Methods("POST")
	
	log.Println("Starting HTTP server at 8080")

	return http.ListenAndServe(":8080", r)
}

func (s *Server) renderTemplate(w http.ResponseWriter, tmpl string, data templateData) {
	t, err := template.ParseFiles(filepath.Join(getCwd(), "web/templates", tmpl+".html"))
	if err != nil {
		log.Print("Error with parsing")
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	err = t.Execute(w, data)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
}

func getCwd() string {
	cwd, _ := os.Getwd()
	return cwd
}

func handleApiError(w http.ResponseWriter, err error) {
	log.Println(err)
	if _, ok := err.(*apiclient.ApiError); ok {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	http.Error(w, "Something went wrong while connecting to the backend service", http.StatusInternalServerError)
}
