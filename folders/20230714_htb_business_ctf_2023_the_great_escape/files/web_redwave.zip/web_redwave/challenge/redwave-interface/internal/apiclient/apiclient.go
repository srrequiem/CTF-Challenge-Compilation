package apiclient

import (
	"bytes"
	"encoding/json"
	"fmt"
	"gemshop-interface/internal/models"
	"github.com/google/uuid"
	"net/http"
)

type ApiClient struct {
	Url string
}

func (client *ApiClient) FindUser(request FindUserRequest) (models.User, error) {
	encodedJson, err := json.Marshal(request)
	if err != nil {
		return models.User{}, err
	}

	resp, err := http.Post(
		fmt.Sprintf("%s/user/find", client.Url), "application/json", bytes.NewBuffer(encodedJson),
	)

	if err != nil {
		return models.User{}, err
	}

	// decode json response
	var response FindUserResponse
	err = json.NewDecoder(resp.Body).Decode(&response)
	if err != nil {
		return models.User{}, err
	}

	if response.Success == 0 && response.Message != "" {
		return models.User{}, NewApiError(response.Message)
	}

	return response.User, nil
}

func (client *ApiClient) CreateUser(request CreateUserRequest) (models.User, error) {
	request.UID = uuid.NewString()
	encodedJson, err := json.Marshal(request)
	if err != nil {
		return models.User{}, err
	}

	resp, err := http.Post(
		fmt.Sprintf("%s/user/create", client.Url), "application/json", bytes.NewBuffer(encodedJson),
	)

	if err != nil {
		return models.User{}, err
	}

	// decode json response
	var response CreateUserResponse
	err = json.NewDecoder(resp.Body).Decode(&response)
	if err != nil {
		return models.User{}, err
	}

	if response.Success == 0 && response.Message != "" {
		return models.User{}, NewApiError(response.Message)
	}

	return response.User, nil
}

func (client *ApiClient) ReadUserBroadcast(user models.User) (models.Broadcast, error) {
	req, err := http.NewRequest(http.MethodGet, fmt.Sprintf("%s/broadcasts/readone", client.Url), nil)
	if err != nil {
		return models.Broadcast{}, err
	}

	req.Header.Set("X-Authorization-User", user.UID)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return models.Broadcast{}, err
	}
	var response ReadUserBroadcastResponse
	err = json.NewDecoder(resp.Body).Decode(&response)
	if err != nil {
		return models.Broadcast{}, err
	}

	if response.Success == 0 && response.Message != "" {
		return models.Broadcast{}, NewApiError(response.Message)
	}

	return response.Broadcast, nil
}



func (client *ApiClient) EditUser(requestBody []byte, user models.User) error {
	req, err := http.NewRequest(
		http.MethodPost, fmt.Sprintf("%s/user/edit", client.Url), bytes.NewBuffer(requestBody),
	)
	if err != nil {
		return err
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Authorization-User", user.UID)

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	var response EditUserResponse
	err = json.NewDecoder(resp.Body).Decode(&response)
	if err != nil {
		return err
	}

	if response.Success == 0 && response.Message != "" {
		return NewApiError(response.Message)
	}

	return nil
}
