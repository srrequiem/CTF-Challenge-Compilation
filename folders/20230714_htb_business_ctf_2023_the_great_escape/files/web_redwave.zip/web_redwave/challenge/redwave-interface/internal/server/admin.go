package server

import (
	"bytes"
	"encoding/json"
	"gemshop-interface/internal/models"
	"io"
	"log"
	"net"
	"net/http"
	"strings"
)

func (s *Server) handleAdmin(w http.ResponseWriter, r *http.Request) {
	s.checkAdmin(w, r)

	s.renderTemplate(w, "admin", templateData{
		"user": nil,
	})
}

func (s *Server) handleAdminPost(w http.ResponseWriter, r *http.Request) {
	s.checkAdmin(w, r)

	var url models.Url
	err := json.NewDecoder(r.Body).Decode(&url)
	if err != nil {
		log.Println(err)
		http.Error(w, "Something went wrong", http.StatusInternalServerError)
		return
	}

	reqBody := bytes.NewBuffer([]byte(url.Body))
	req, err := http.NewRequest(http.MethodPost, url.URL, reqBody)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	req.Header = r.Header.Clone()

	localIps := []string{"http://localhost", "http://127.0.0.1", "http://0.0.0.0", ":1"}
	for _, ip := range localIps {
		if strings.Contains(url.URL, ip) {
			if net.ParseIP(req.Header.Get("X-Forwarded-For")).String() != "127.0.0.1" {
				req.Header.Set("X-Forwarded-For", "127.0.0.1")
			}
		}
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Write(body)
}

func (s *Server) checkAdmin(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("session_token")
	if err != nil {
		http.Redirect(w, r, "/", http.StatusFound)
		return
	}

	user, ok := s.sessions[cookie.Value]
	if !ok {
		http.Error(w, "Error retrieving user.", http.StatusBadRequest)
		return
	}

	if user.UID != "" {
		http.Error(w, "Not an admin!", http.StatusUnauthorized)
		return
	}
}
