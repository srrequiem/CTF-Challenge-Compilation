package server

import (
	"encoding/json"
	"gemshop-interface/internal/apiclient"
	"gemshop-interface/internal/models"
	"github.com/google/uuid"
	"log"
	"net/http"
	"time"
)

func (s *Server) handleSignIn(w http.ResponseWriter, r *http.Request) {
	s.renderTemplate(w, "signin", templateData{
		"user": models.User{
			Username: "Guest",
		},
	})
}

func (s *Server) handleSignInPost(w http.ResponseWriter, r *http.Request) {
	var user models.User
	// decode user from body
	err := json.NewDecoder(r.Body).Decode(&user)
	if err != nil {
		log.Println(err)
		http.Error(w, "Something went wrong", http.StatusInternalServerError)
		return
	}

	// send request to ruby app
	apiUser, err := s.apiClient.FindUser(apiclient.FindUserRequest{
		Username: user.Username,
	})
	if err != nil {
		handleApiError(w, err)
		return
	}

	if apiUser.Password != user.Password {
		http.Error(w, "Invalid credentials", http.StatusUnauthorized)
		return
	}

	sessionKey := uuid.NewString()
	http.SetCookie(w, &http.Cookie{
		Name:    "session_token",
		Value:   sessionKey,
		Expires: time.Now().Add(600 * time.Second),
	})
	s.sessions[sessionKey] = apiUser

	http.Redirect(w, r, "/", http.StatusFound)
}
