package server

import (
	"encoding/json"
	"fmt"
	"gemshop-interface/internal/apiclient"
	"log"
	"net/http"
)

func (s *Server) handleRegister(w http.ResponseWriter, r *http.Request) {
	var requestData apiclient.CreateUserRequest
	err := json.NewDecoder(r.Body).Decode(&requestData)
	if err != nil {
		log.Println(err)
		http.Error(w, "Something went wrong", http.StatusInternalServerError)
		return
	}

	user, err := s.apiClient.CreateUser(requestData)
	if err != nil {
		handleApiError(w, err)
		return
	}

	fmt.Println(user)
}
