package apiclient

import (
	"gemshop-interface/internal/models"
)

type apiResponse struct {
	Success int    `json:"success"`
	Message string `json:"message"`
}
type ApiError struct {
	s string
}

func NewApiError(s string) error {
	return &ApiError{s: s}
}

func (e ApiError) Error() string {
	return e.s
}

type FindUserRequest struct {
	Username string `json:"username"`
}

type FindUserResponse struct {
	apiResponse
	models.User
}

type CreateUserRequest struct {
	UID      string `json:"UID"`
	Username string `json:"username"`
	Password string `json:"password"`
	BroadcastChannel   string `json:"broadcastChannel"`
}

type CreateUserResponse struct {
	apiResponse
	models.User
}

type ReadUserBroadcastResponse struct {
	apiResponse
	models.Broadcast
}


type EditUserResponse apiResponse
