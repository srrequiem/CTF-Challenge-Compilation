package models

type User struct {
	UID      string
	Username string `json:"username"`
	Password string `json:"password"`
	BroadcastChannel    string `json:"broadcastChannel"`
}

type Broadcast struct {
	Category       string 
	Description string
}

type Url struct {
	URL  string `json:"url"`
	Body string `json:"body"`
}
