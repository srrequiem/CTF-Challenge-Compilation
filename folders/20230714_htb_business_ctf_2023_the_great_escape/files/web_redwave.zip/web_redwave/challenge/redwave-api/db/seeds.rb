# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{name: "Star Wars" }, {name: "Lord of the Rings" }])
#   Character.create(name: "Luke", movie: movies.first)

json_broadcast = Broadcast.create([
    {description: "Urgent assistance required. We face a crisis and seek your support. Please respond as soon as possible.", category: "SOS 080316"},
    {description: "Calling upon medical professionals. We require your expertise to address a challenging health issue. Help us save lives.", category: "Medical Expertise Needed 021120"},
    {description: "Seeking your knowledge in sustainable food production. Share innovative methods to ensure long-term food security on Mars.", category: "Sustainable Food Solutions 150622"},
    {description: "Our ecosystems are in peril. We humbly request guidance and collaboration to restore and preserve the delicate balance of nature.", category: "Environmental Restoration Efforts 041218"},
    {description: "Requesting technological support to overcome a critical problem. Your expertise in this area can make a significant difference.", category: "Technological Assistance Requested 190317"},
    {description: "Inviting educators and researchers to collaborate with us. Let's jointly develop educational initiatives for a brighter future.", category: "Educational Collaboration 301219"},
    {description: "We face an energy crisis that demands innovative solutions. We seek your guidance to develop sustainable energy sources.", category: "Energy Crisis 080524"},
    {description: "A devastating disaster has struck our region. We appeal for your assistance in providing aid and relief to affected communities.", category: "Disaster Relief Assistance 011019"},
    {description: "Proposing a collaborative partnership in space exploration. Together, we can unlock new frontiers and advance our understanding of the cosmos.", category: "Space Exploration Partnership 210615"},
    {description: "Our cultural heritage is at risk. We kindly ask for your support in preserving and safeguarding our diverse traditions and knowledge.", category: "Cultural Preservation 071014"}
])