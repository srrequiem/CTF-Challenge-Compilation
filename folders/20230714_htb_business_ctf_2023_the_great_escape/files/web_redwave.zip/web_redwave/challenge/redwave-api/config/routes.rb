Rails.application.routes.draw do
  post "/user/healthcheck", to: "users#healthcheck"
  post "/user/create", to: "users#createUser"
  post "/user/find", to: "users#readUser"
  post "/user/edit", to: "users#updateUser"
  get "/broadcasts/readone", to: "broadcast#readUserBroadcastChannel"
end
