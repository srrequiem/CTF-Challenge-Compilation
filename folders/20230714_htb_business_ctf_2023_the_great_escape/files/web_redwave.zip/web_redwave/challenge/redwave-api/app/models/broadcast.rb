class Broadcast < ApplicationRecord
end
