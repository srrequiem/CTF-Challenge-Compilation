class UsersController < ApplicationController
    def createUser
        req_body = JSON.parse(request.body.read)
        if User.exists?(username: req_body["username"])
            render json: '{"success":0, "message": "User already exists."}', :status => 400
            return
        end
        user = User.create(username: req_body["username"], password: req_body["password"], uid: req_body["UID"])
        render json: user
    end

    def readUser
        req_user = JSON.parse(request.body.read)
        if User.exists?(username: req_user["username"])
            user = User.lock.find_by(username: req_user["username"])
            render json: user
            return
        end
        render json: '{"success":0, "message":"User not found."}', :status => 404
    end

    def updateUser
        req_uid = request.headers["X-Authorization-User"]
        json_user =  JSON.parse(request.body.read)
        if req_uid != json_user["UID"]
            render json: '{"success":0, "message":"Bad Request"}', :status => 400
            return
        end
        if User.exists?(UID: req_uid)
            user = User.lock.where(UID: req_uid, username: json_user["username"]).first
            user.broadcastChannel = json_user["category"]
            puts json_user
            user.save
            render json: '{"success":1}', :status => 200
            return
        end
        render json: '{"success":0, "message":"Bad Request"}', :status => 400
    end
    
    def healthcheck
        requester_ips =  Socket.getaddrinfo(request.ip, "http", nil)
        anti_ssrf = ["127.0.0.1", "::1", "0.0.0.0"]
        for ip in requester_ips do
            if (ip & anti_ssrf).any?
                render json: '{"success":0, "message":"Bad Request"}'
                return
            end
        end
        # Load complex class definitions
        Oj.load(request.body.read)
        render json: '{"success":1, "message":"Bad Request"}'
    end

end
