class BroadcastController < ApplicationController
    def readUserBroadcastChannel
        req_uid = request.headers["X-Authorization-User"]
        if User.exists?(UID: req_uid)
            u = User.lock.where(UID: req_uid).first
            puts "--------------------------------------------------------"
            bmsge = Broadcast.lock.where(category: u["broadcastChannel"]).order('RANDOM()').first
            render json: bmsge
            return
        end
        render json: '{"success":0, "message":"Unable to find user"}', :status => 400
        return
    end
end
