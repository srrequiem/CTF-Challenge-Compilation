from flask import Flask, request
from lxml import etree
import traceback

app = Flask(__name__)


@app.route('/')
def index():
    return """
    <html>
    <head><title>H4x0r</title></head>
    <body>
        <p><h3>Funciones</h3></p>
        <a href="/rest">Rifate master!</a><br>
        <a href="/flag">Flag</a><br>
    </body>
    </html>
    """

@app.route('/flag')
def flag():
    return """
    <html>
    <head><title>Spiderman</title></head>
    <body>
        <p><h3>No sera tan facil. La flag esta en /flag.txt</h3></p>
    </body>
    </html>
    """

@app.route('/rest', methods=['POST', 'GET'])
def xml():
    parsed_xml = None

    html = """
    <html>
      <body>
    """

    if request.method == 'POST':
        xml = request.form['comment']
        parser = etree.XMLParser(no_network=False)
        try:
            doc = etree.fromstring(str(xml), parser)
            parsed_xml = etree.tostring(doc)
            #print(repr(parsed_xml))
        except:
            print("Cannot parse the xml")
            html += "Error:\n<br>\n" + traceback.format_exc()
    if (parsed_xml):
        html += "Respuesta:\n<br>\n" + parsed_xml.decode()
    else:
        html += """
	  <form action = "/rest" method = "POST">
		 <p><h3>Mandame un saludo!</h3></p>
		 <textarea class="input" name="comment" cols="40" rows="5"></textarea>
		 <p><input type = 'submit' value = 'enviar'/></p>
	  </form>
	"""

    html += """
      </body>
    </html>
    """

    return html


if __name__ == '__main__':
    app.run(debug=True, port=4444, host='0.0.0.0')
