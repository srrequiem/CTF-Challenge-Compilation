<style>
    .perrin {
        text-shadow: 2px 2px red;
    }
</style>
<div class="main-wrapper">
<h1 class="perrin">Ah perrin le sabes al LFI</h1>
<h2 class="perrin">No creas que va a ser tan fácil obtener tu flag</h2>
<?php
  $flag = "LPM{4h_p3rr1n_lf1_4_7h3_w1n}";
	echo("¿Ya pensaste en algo diferente?");
?>
</div>