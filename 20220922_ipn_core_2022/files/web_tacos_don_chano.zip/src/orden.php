<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <title>Los Fabulosos Tacos Don Chano</title>
        <link rel="stylesheet" href="style.css" />
    </head>
    <body>
        <h1 style="text-align: center">En seguida sale su orden joven</h1>
        <div class="container">
            <div class="order">
                <h3>Mi orden</h3>
                <div class="description">
                    <div style="width: 100%;color: #888;text-align: center;">
                        <p>No.</p>
                        <p>Cantidad</p>
                        <p>Tipo</p>
                        <p>Estado</p>
                    </div>
                    <div style="width: 100%;color: #444;">
                      <?php
                        $db = new SQLite3('../tacos-CA01F2F549.db');
                        $res = $db->query("SELECT * FROM orders WHERE id = " . $_GET["id"]);
                        while ($row = $res->fetchArray()) {
                          echo '<p>' . $row['id'] . '</p>';
                          echo '<p>' . $row['quantity'] . '</p>';
                          echo '<p>' . $row['name'] . '</p>';
                          echo '<p>Preparando...</p>';
                        }
                      ?>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>