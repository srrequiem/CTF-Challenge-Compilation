#!/bin/bash
docker rm -f web_emoji_letters
docker build --tag=web_emoji_letters .
docker run -p 1337:80 --rm --name=web_emoji_letters -it web_emoji_letters