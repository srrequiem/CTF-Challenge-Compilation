import uuid
from flask import render_template, redirect, request, current_app, Blueprint, jsonify
from application.database import User, Letter, db
from flask_login import login_required, login_user, logout_user
from application.util import retireve_json
from application.bot import visit_letter

web = Blueprint('web', __name__)
api = Blueprint('api', __name__)

def response(message, status=200):
    return jsonify({'message': message}), status

@web.route("/")
def index():
    return render_template('index.html')

@web.route("/letter")
def letter():
    return render_template('letter.html')

@api.route('/create', methods=['POST'])
def createLetter():
    if not request.is_json:
        return response('Missing required parameters!', 401)

    data = request.get_json()
    userLetter = data.get('userLetter', '')
    userEmoji = data.get('userEmoji', '')

    if not userLetter or not userEmoji:
        return response('Missing required parameters!', 401)

    uid = str(uuid.uuid4())

    try:
        newLetter = Letter(uid=uid, letter=userLetter, emoji=userEmoji)
        db.session.add(newLetter)
        db.session.commit()
        return jsonify({'message': 'Letter created successfully', 'uid': uid})
    except:
        return response('Something went wrong', 500)

@api.route('/letter', methods=['POST'])
def viewLetter():
    if not request.is_json:
        return response('Missing required parameters!', 401)

    data = request.get_json()
    uid = data.get('uid', '')

    if not uid:
        return response('Missing required parameters!', 401)

    userLetter = Letter.query.filter_by(uid=uid).first()

    if not userLetter:
        return response('Letter does not exist', 403)

    return userLetter.to_dict()

@api.route('/report', methods=['POST'])
def report_issue():
    if not request.is_json:
        return response('Missing required parameters!', 401)

    data = request.get_json()
    uid = data.get('uid', '')

    if not uid:
        return response('Missing required parameters!', 401)

    visit_letter(uid)

    return response('Letter reported successfully!')


@web.route('/login', methods=['GET'])
def login():
    return render_template('login.html')

@api.route('/login', methods=['POST'])
def user_login():
    if not request.is_json:
        return response('Missing required parameters!', 401)

    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')

    if not username or not password:
        return response('Missing required parameters!', 401)

    user = User.query.filter_by(username=username).first()

    if not user or not user.password == password:
        return response('Invalid username or password!', 403)

    login_user(user)
    return response('User authenticated successfully!')

@web.route('/admin')
@login_required
def dashboard():
    with open(current_app.config['EMOJI_PACK_PATH']) as epack:
        emojiContent = epack.read()

    return render_template('admin.html', emojiContent=emojiContent)

@api.route('/admin/emoji-pack/update', methods=['POST'])
@login_required
def emojiUpdate():
    if not request.is_json:
        return response('Missing required parameters!', 401)

    data = request.get_json()
    emojiData = data.get('emojiData', '')

    if not emojiData:
        return response('Missing required parameters!', 401)

    with open(current_app.config['EMOJI_PACK_PATH'], 'w') as epack:
        epack.write(emojiData)

    return response('Emoji pack updated successfully!')

@api.route('/admin/emoji-pack/import', methods=['POST'])
@login_required
def emojiImport():
    if not request.is_json:
        return response('Missing required parameters!', 401)

    data = request.get_json()
    emojiURL = data.get('emojiURL', '')

    if not emojiURL:
        return response('Missing required parameters!', 401)

    result = retireve_json(emojiURL)

    if (type(result)) is not dict:
        return response(result, 401)

    with open(current_app.config['EMOJI_PACK_PATH'], 'w') as epack:
        epack.write(result)

    return response('Emoji pack updated successfully!')

@web.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/')
