window.onload = () => {
    $('#createLetter').on('click', createLetter);
}

const createLetter = async () => {

    let card = $('#resp-msg');
    card.text('Creating user profile');
    card.show();

    let userLetter = $('#userLetter').val();
    if ($.trim(userLetter) == '') {
        card.text('Please input a secret first!');
        return;
    }

    let userEmoji = $('#userEmoji').val();

    await fetch('/api/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            userLetter,
            userEmoji
        }),
    })
    .then((response) => response.json()
        .then((resp) => {
            if (response.status == 200) {
                location.href = '/letter?uid='+resp.uid;
            }
            if (resp.hasOwnProperty('message')) {
                card.text(resp.message);
            }
        }))
    .catch((error) => {
        console.error(error);
    });

}

