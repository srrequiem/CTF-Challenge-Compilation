window.onload = () => {
    $('#updateJSON').on('click', updateJSON);
}

const updateJSON = async () => {

    let emojiData = $('#emojiJSON').val();

    await fetch('/api/admin/emoji-pack/update', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({emojiData}),
    })
    .then((response) => {
        location.reload();
    })
    .catch((error) => {
        console.error(error);
    });
}

const uploadSVG = async () => {
    let svgFile = new File([makeSVG()], "avatar.svg", {type: "image/svg+xml"})
    let formData = new FormData();
	formData.append('avatarFile', svgFile);

    await fetch('/api/upload', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: formData,
    })
    .then((response) => response.json()
        .then((resp) => {
            if (resp.hasOwnProperty('avatarFile')) {
                $('#spriteAvatar').val(resp.avatarFile);
                $('#upSprite').hide();
                $('#genSprite').hide();
                $('#avatar-resp').text(resp.message);
                $('#avatar-resp').show();
            }
        }))
    .catch((error) => {
        console.error(error);
    });

}

