window.onload = () => {
    params = $.parseParams(location.search);
    if (!params.hasOwnProperty('uid')) location.href = '/';
    loadLetter(params.uid);
    $('#reportLetter').on('click', () => { reportLetter(params.uid) });
}

const loadLetter = async (uid) => {

    await fetch('/api/letter', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            uid
        }),
    })
    .then((response) => response.json()
        .then((resp) => {
            if (response.status != 200) {
                location.href = '/';
            }
            $('.emoji-pattern').html(filterXSS(resp.emoji));
            $('#letterContent').text(filterXSS(resp.letter));
        }))
    .catch((error) => {
        console.error(error);
    });

}

const reportLetter = async (uid) => {

    $('#resp-msg').show()

    await fetch('/api/report', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            uid
        }),
    })
    .then((response)  => {
        location.href = '/';
    })
    .catch((error) => {
        console.error(error);
    });
}