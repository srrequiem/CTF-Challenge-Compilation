// Source: https://codepen.io/tvweinstock/pen/zzybdP

const endpoint = '/static/emoji.json';
const emojis = [];
const searchInput = document.querySelector('.search');
const suggestions = document.querySelector('.suggestions');
const emojiPattern = Array.from(document.querySelectorAll('.emoji-pattern'));

fetch(endpoint).
then(blob => blob.json()).
then(data => emojis.push(...data)).
then(() => {
  renderMatches(emojis);
}).
catch(err => {
  console.log(err);
});

function findMatches(wordToMatch, emojis) {
  return emojis.filter((emoji) =>
  emoji.aliases.some(alias => alias.indexOf(wordToMatch) !== -1));

}

function renderMatches(arr) {
  const html = arr.map(emo => {
    const {
      emoji,
      description } =
    emo;
    return `
      <li class="icon">
        <abbr title="${description}">${emoji}</abbr>
      </li>
    `;
  }).join('');
  suggestions.innerHTML = html;
}

function updateMatches() {
  const matchArray = findMatches(this.value, emojis);
  renderMatches(matchArray);
}

function changeBackground(e) {
  if (!e.target.matches('abbr')) return;
  const emoj = e.target.innerText;
  $('#userEmoji').val(emoj);
  emojiPattern.map(pattern => pattern.textContent = emoj);

}

searchInput.addEventListener('change', updateMatches);
searchInput.addEventListener('keyup', updateMatches);
suggestions.addEventListener('click', changeBackground);
