// source: https://codepen.io/xgqfrms/pen/mmZbpz

var progressBar = document.getElementById('progress'),
    percent = document.getElementsByClassName('dprogress-bar__percent')[0],
    percentCloned = percent.cloneNode(false),
    count = 1;

var appendPercent = function() {
  if (count > 17) {
    clearInterval(window.loadAnimation);
    $('.loading-container').hide();
    return;
  } else {
    progress.appendChild(percentCloned);
    percentCloned = percent.cloneNode(false);
    count++;
  }
};

window.loadAnimation = setInterval(appendPercent, 100);