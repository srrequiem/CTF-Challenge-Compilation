from application.util import generate
import os

class Config(object):
    SECRET_KEY = generate(50)
    UPLOAD_DIR = f'{os.getcwd()}/application/static/uploads'
    ADMIN_USERNAME = 'admin'
    ADMIN_PASSWORD = generate(15)
    SESSION_TYPE = 'filesystem'
    EMOJI_PACK_PATH = f'{os.getcwd()}/application/static/emoji.json'
    SQLALCHEMY_DATABASE_URI = 'sqlite:////tmp/database.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

class ProductionConfig(Config):
    pass

class DevelopmentConfig(Config):
    DEBUG = True

class TestingConfig(Config):
    TESTING = True