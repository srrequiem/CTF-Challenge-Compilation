from application.main import app
from application.database import migrate_db

with app.app_context():
    migrate_db()

if __name__ == "__main__":
    app.run(host='0.0.0.0')
