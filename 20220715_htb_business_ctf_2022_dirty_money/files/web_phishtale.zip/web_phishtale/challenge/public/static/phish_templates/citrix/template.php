<!DOCTYPE html PUBLIC "-//W3C//DTD XDEV_HTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>NetScaler Gateway</title>
<link rel="SHORTCUT ICON" href="AccessGateway.ico" type="image/vnd.microsoft.icon">

<meta content="noindex,nofollow,noarchive" name="robots">
<link href="./index_files/rdx.css" rel="stylesheet" type="text/css">
<link href="./index_files/base.css" rel="stylesheet" type="text/css" media="screen">
<link rel="stylesheet" href="./index_files/citrix-fonts.css" type="text/css">
<link href="./index_files/custom.css" rel="stylesheet" type="text/css">


<meta content="MSHTML 6.00.2900.2802" name="GENERATOR">
</head><div id="abineFillElement"></div>
<body class="ns_body" id="bodyTag" style="display: block; visibility: visible;">
<noscript>
<BR><BR>
<table style="WIDTH: 100%">
<tr>
        <td align="center">
                <table class="CTXMSAM_LogonFont">
                        <tr id="errorMessageRow">
                                <td class="glowBoxLeft">&nbsp;</td>
                                <td class="loginTableMidWidth">
                                        <div id="feedbackArea">
                                        <div id="feedbackStyle" class="feedbackStyleError">
                                        <span id="errorMessageLabel" class="messageStyle">
                                        JavaScript is either disabled in or not supported by the Web browser.
                                        To continue logon, use a Web browser that supports JavaScript or enable JavaScript in your current browser.
                                        </span>
                                        </div>
                                        </div>
                                </td>
                                <td class="glowBoxRight">&nbsp;</td>
                        </tr>
                </table>
        </td>
</tr>
</table>

<table style="display:none">
</noscript>



<div class="activity_status_bar"><div class="activity_bar activity_status_bar_position" style="display: none;"><span></span></div><div class="status_bar activity_status_bar_position" style="display: none;"><span></span></div></div><div class="base_view_no_view_top_container"><div><div class="header_parent_div"><div class="ns_header ns_header_view_panel" style=""><table class="full_width_table ns_banner_table rdx_page_center_align header_info" cellpadding="0" cellspacing="0"><tbody><tr><td></td><td><div class="header_info_right"><ul><li class="header_view_menu_settings_link_app_search header_view_menu_settings_link"><a class="app_search_button_in_header_hide"></a></li></ul></div></td></tr></tbody></table></div></div></div></div><div class="center_panel" style="display: block;"><table align="center" class="loading_panel"><tbody><tr><td class="loading_panel_img"><img src="./index_files/in_progress.gif"></td><td class="loading_panel_txt">rdx.page_loading</td></tr></tbody></table></div><div class="rdx_message_container rdx_page_center_align" style="width: 1284px;"></div><div class="ns_content rdx_page_center_align" style="display: block; width: 1284px; min-height: 710px;"></div><div class="popup popup_info">rdx.page_auto_refresh_off</div><div class="view_div_decorator base_view_no_view_top_container"><div><div id="authentication" style="margin-top: -128.5px;"><div id="logonbelt-topshadow"><table class="full_width"><tbody><tr id="row1"><td class="header_left"></td></tr><tr id="row2"><td colspan="2" class="navbar"></td></tr></tbody></table></div><div id="logonbox-container"><div id="logonbox-innerbox">

<div id="logonbox-logoarea">
<p align="right"><br /><img src="logo-citrix.png" align="right" width="200"></p><p><br></p></div><div id="logonbox-logonform" class="clearfix"><div class="view_div_decorator base_view_no_view_top_container">
<div>

<form method="post" action="/" name="vpnForm" autocomplete="off" style="magin:0" id="vpnForm" abineguid="0C0C6BE6E6204A8989FB93F4450F1C6A">


<div id="ctl08_loginAgentCdaHeaderText2" class="CTX_ContentTitleHeader login_page"><br>Please log on</div><div class="field clearfix CredentialTypeusername"><div class="left"><span class="plain input_labels form_text" id="User_name">User name</span></div><div class="right">


<input type="text" id="Enter user name" class="prePopulatedCredentials" autocomplete="off" spellcheck="true" name="username" size="30" maxlength="127" width="0" autofocus="" title="Enter user name"></div></div><div class="field clearfix CredentialTypepassword"><div class="left">

<span class="plain input_labels form_text" id="Password">Password</span></div><div class="right"><input type="password" id="passwd" class="prePopulatedCredentials" autocomplete="off" spellcheck="true" name="password" size="30" maxlength="127" width="0"></div></div><div class="field CredentialTypenone"><div class="left">


<div class="field buttons"><div class="left"></div><div class="right"><input type="submit" id="Log_On" value="Log On" class="custombutton login_page" name="a7969814138464439"></div></div></form></div></div></div></div></div><div id="logonbelt-bottomshadow"><div style="text-align:center;color:white;font-size:18px;"></div></div></div></div></div></body><div class="abineContentPanel" style="background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: transparent !important; margin: 0px !important; padding: 0px !important; opacity: 1 !important; z-index: 2147483647 !important; position: absolute !important; overflow: hidden !important; border-width: 0px !important; visibility: visible !important; display: none;"></div></html>
